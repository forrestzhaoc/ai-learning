Examples were moved to the separate repository: [cube-js/examples](https://github.com/cube-js/examples)
