export const TOCTitle = () => {
  return (
    <div className="TOCTitle">
      <h1 className="nx-mt-2 nx-text-4xl nx-font-bold nx-tracking-tight">TOC</h1>
    </div>
  );
};
