module.exports = {
  "environment-variables": "Environment variables",
  "using-ssl-connections-to-data-source": "SSL",
  "data-store-cost-saving-guide": "Data source usage",
  "multiple-sources-same-schema": "Per-tenant data sources",
  "custom-data-model-per-tenant": "Per-tenant data models"
}
