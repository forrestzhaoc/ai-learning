module.exports = {
  "data-sources": "Data sources",
  "visualization-tools": "Visualization tools",
  "multiple-data-sources": "Multiple data sources",
  "concurrency": "Concurrency",
  "multitenancy": "Multitenancy",
  "reference": "Reference",
  "recipes": "Recipes"
}
