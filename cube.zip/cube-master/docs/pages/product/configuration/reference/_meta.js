module.exports = {
  "environment-variables": "Environment variables",
  "config": "Configuration options"
}