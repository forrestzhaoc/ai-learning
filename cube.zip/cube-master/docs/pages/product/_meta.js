module.exports = {
  "introduction": "Introduction",
  "getting-started": "Getting started",
  "configuration": "Data Sources & Config",
  "data-modeling": "Data modeling",
  "exploration": "Explore & Analyze",
  "presentation": "Present & Share",
  "caching": "Caching",
  "auth": "Access control",
  "apis-integrations": "APIs & integrations",
  "administration": "Administration"
}