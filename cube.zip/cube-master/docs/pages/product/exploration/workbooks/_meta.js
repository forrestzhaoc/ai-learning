module.exports = {
  "querying-data": "Querying data",
  "source-sql-tabs": "Source SQL Tabs",
  "charts": "Charts",
}

