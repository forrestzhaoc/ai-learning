module.exports = {
  "workbooks": "Workbooks",
  "explore": "Explore",
  "analytics-chat": "Analytics Chat",
  "playground": "Playground",
}

