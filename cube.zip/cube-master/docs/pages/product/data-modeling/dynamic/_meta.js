module.exports = {
  "jinja": "YAML, Jinja, and Python",
  "javascript": "JavaScript",
  "code-reusability-export-and-import": "Export and import",
  "schema-execution-environment": "Execution environment (JavaScript)"
}