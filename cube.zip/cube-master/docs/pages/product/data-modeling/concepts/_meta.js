module.exports = {
  "calculated-members": "Calculated members",
  "multi-stage-calculations": "Multi-stage calculations",
  "working-with-joins": "Joins between cubes",
  "calendar-cubes": "Calendar cubes",
  "code-reusability-extending-cubes": "Extension",
  "polymorphic-cubes": "Polymorphic cubes",
  "data-blending": "Data blending"
}
