module.exports = {
  "cube": "Cubes",
  "view": "Views",
  "measures": "Measures",
  "dimensions": "Dimensions",
  "hierarchies": "Hierarchies",
  "segments": "Segments",
  "joins": "Joins",
  "pre-aggregations": "Pre-aggregations",
  "data-access-policies": "Access policies",
  "types-and-formats": "Types and formats",
  "context-variables": "Context variables",
  "cube-package": "cube package",
  "cube_dbt": "cube_dbt package",
  "lkml2cube": "lkml2cube package"
}