module.exports = {
  "overview": "Overview",
  "concepts": "Concepts",
  "syntax": "Syntax",
  "dynamic": "Dynamic data models",
  "reference": "Reference",
  "recipes": "Recipes"
}