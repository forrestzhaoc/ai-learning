module.exports = {
  "non-additivity": "Non-additive measures",
  "incrementally-building-pre-aggregations-for-a-date-range": "Incremental pre-aggregations",
  "disabling-pre-aggregations": "Disabling pre-aggregations",
  "using-originalsql-and-rollups-effectively": "Using original_sql and rollup pre-aggregations effectively",
  "refreshing-select-partitions": "Refreshing select partitions",
  "joining-multiple-data-sources": "Joining data from multiple data sources"
}
