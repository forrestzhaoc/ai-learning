module.exports = {
  "getting-started-pre-aggregations": "Getting started with pre-aggregations",
  "using-pre-aggregations": "Using pre-aggregations",
  "matching-pre-aggregations": "Matching pre-aggregations",
  "refreshing-pre-aggregations": "Refreshing pre-aggregations",
  "lambda-pre-aggregations": "Lambda pre-aggregations",
  "running-in-production": "Running in production",
  "recipes": "Recipes"
}