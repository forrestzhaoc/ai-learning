module.exports = {
  "dashboards": "Dashboards",
  "embedding": "Embedding"
}

