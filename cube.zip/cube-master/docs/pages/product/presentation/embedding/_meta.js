module.exports = {
  "private-embedding": "Private embedding",
  "signed-embedding": "Signed embedding"
}
