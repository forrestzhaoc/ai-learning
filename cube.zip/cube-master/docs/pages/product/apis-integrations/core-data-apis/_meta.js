module.exports = {
  "queries": "Queries",
  "sql-api": "SQL API",
  "dax-api": "DAX API",
  "mdx-api": "MDX API",
  "rest-api": "REST API",
  "graphql-api": "GraphQL API"
};

