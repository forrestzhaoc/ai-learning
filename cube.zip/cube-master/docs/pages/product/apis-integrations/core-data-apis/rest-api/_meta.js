module.exports = {
  "query-format": "Query format",
  "reference": "Reference"
}