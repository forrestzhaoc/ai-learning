module.exports = {
  "query-format": "Query format",
  "joins": "Joins",
  "security": "Authentication and Authorization",
  "reference": "Reference"
}