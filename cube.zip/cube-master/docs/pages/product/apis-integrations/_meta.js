module.exports = {
  "embed-apis": "Embed APIs",
  "core-data-apis": "Core Data APIs",
  "orchestration-api": "Orchestration API",
  "mcp-server": "MCP server",
  "microsoft-excel": "Cube Cloud for Excel",
  "google-sheets": "Cube Cloud for Sheets",
  "semantic-layer-sync": "Semantic Layer Sync",
  "javascript-sdk": "JavaScript SDK",
  "recipes": "Recipes"
};
