module.exports = {
  "getting-unique-values-for-a-field": "Unique values",
  "cast-numerics": "Numeric values",
  "sorting": "Custom sorting",
  "pagination": "Pagination",
  "drilldowns": "Drilldowns",
  "real-time-data-fetch": "Real-time data fetch"
}
