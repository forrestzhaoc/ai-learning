module.exports = {
  "cubejs-client-core": "core",
  "cubejs-client-react": "react",
  "cubejs-client-ngx": "ngx",
  "cubejs-client-vue": "vue",
  "cubejs-client-ws-transport": "ws-transport"
}