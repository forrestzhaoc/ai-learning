module.exports = {
  "react": "React",
  "vue": "Vue",
  "angular": "Angular",
  "reference": "Reference"
}