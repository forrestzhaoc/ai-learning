module.exports = {
  "chat-api": "Chat API",
  "generate-session": "Generate Session"
};

