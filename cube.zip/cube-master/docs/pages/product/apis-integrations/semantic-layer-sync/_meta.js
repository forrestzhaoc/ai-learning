module.exports = {
  "superset": "Apache Superset",
  "metabase": "Metabase",
  "preset": "Preset",
  "tableau": "Tableau"
}