module.exports = {
  aws: "AWS",
  azure: "Azure",
  gcp: "GCP",
};
