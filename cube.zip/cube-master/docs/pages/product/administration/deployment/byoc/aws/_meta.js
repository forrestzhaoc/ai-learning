module.exports = {
  deployment: "Deployment",
  privatelink: "Private Connectivity",
};
