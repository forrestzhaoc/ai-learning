module.exports = {
  "aws": "AWS",
  "gcp": "GCP",
  "azure": "Azure"
}