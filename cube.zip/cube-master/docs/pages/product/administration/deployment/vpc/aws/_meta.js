module.exports = {
    "private-link": "PrivateLink",
    "vpc-peering": "VPC Peering",
  }