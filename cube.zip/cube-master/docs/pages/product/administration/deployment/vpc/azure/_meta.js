module.exports = {
  "private-link": "Private Link",
  "vpc-peering": "VNet Peering",
}