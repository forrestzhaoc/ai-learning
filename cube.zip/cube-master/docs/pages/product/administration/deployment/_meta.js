module.exports = {
  "providers": "Cloud providers",
  "infrastructure": "Infrastructure options",
  "vpc": "VPC",
  "byoc": "BYOC",
  "deployments": "Deployments",
  "deployment-types": "Deployment types",
  "continuous-deployment": "Continuous deployment",
  "custom-domains": "Custom domains",
  "warm-up": "Deployment warm-up",
  "auto-suspension": "Auto-suspension",
  "scalability": "Scalability",
  "pricing": "Pricing",
  "support": "Support",
  "limits": "Limits",
  "core": "Cube Core"
}
