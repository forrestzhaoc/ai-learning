module.exports = {
  "google-workspace": "Google Workspace",
  "microsoft-entra-id": "Microsoft Entra ID",
  "okta": "Okta"
}
