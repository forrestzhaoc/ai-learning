module.exports = {
  "query-history-export": "Exporting Query History",
}