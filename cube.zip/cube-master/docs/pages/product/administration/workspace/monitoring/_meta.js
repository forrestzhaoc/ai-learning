module.exports = {
  "cloudwatch": "Amazon CloudWatch",
  "s3": "Amazon S3",
  "datadog": "Datadog",
  "grafana-cloud": "Grafana Cloud"
}