module.exports = {
  "spaces-agents-models": "Spaces, agents, models",
  "agent-rules": "Agent rules",
  "memory-isolation": "Agent memories"
}

