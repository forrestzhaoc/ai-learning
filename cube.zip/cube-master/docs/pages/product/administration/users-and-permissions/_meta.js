module.exports = {
  "roles-and-permissions": "Roles & permissions",
  "user-attributes": "User attributes",
  "user-groups": "User groups",
  "custom-roles": "Custom roles",
}

