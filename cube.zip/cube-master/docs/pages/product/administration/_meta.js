module.exports = {
  "users-and-permissions": "Users & permissions",
  "ai": "AI",
  "workspace": "Workspace",
  "deployment": "Deployment",
  "distribution": "Distribution"
}

