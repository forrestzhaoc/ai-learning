module.exports = {
  "name-password": "Name and password",
  "kerberos": "Kerberos",
  "ntlm": "NTLM",
  "identity-provider": "Identity provider",
  "jwt": "JSON Web Token",
  "auth0": "Auth0",
  "aws-cognito": "AWS Cognito",
  "ldap": "SQL API with LDAP"
}