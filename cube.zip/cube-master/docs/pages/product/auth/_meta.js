module.exports = {
  "data-access-policies": "Access policies",
  "row-level-security": "Row-level security",
  "member-level-security": "Member-level security",
  "methods": "Cube Core Authentication",
  "context": "Security context"
}