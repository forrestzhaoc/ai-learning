module.exports = {
  "load-data": "Load data",
  "connect-to-snowflake": "Connect to Snowflake",
  "create-data-model": "Create data model",
  "query-from-bi": "Query from BI",
  "query-from-react-app": "Query from React"
}