module.exports = {
  "create-a-project": "Create a project",
  "query-data": "Query data",
  "add-a-pre-aggregation": "Add a pre-aggregation",
  "learn-more": "Learn more"
}