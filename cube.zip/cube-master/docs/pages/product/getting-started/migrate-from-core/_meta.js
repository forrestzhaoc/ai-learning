module.exports = {
  "upload-with-cli": "Upload with CLI",
  "import-gitlab-repository-via-ssh": "Import a GitLab repository",
  "import-github-repository": "Import a GitHub repository",
  "import-git-repository-via-ssh": "Import a Git repository",
  "import-bitbucket-repository-via-ssh": "Import a Bitbucket repository"
}