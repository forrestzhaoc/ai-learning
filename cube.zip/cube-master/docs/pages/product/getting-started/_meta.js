module.exports = {
  "cloud": "Cube Cloud and Snowflake",
  "databricks": "Cube Cloud and Databricks",
  "core": "Cube Core",
  "migrate-from-core": "Migrate from Cube Core"
}
