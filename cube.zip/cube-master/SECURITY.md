# Security Policy

## Reporting a Vulnerability

Please email security reports to info@cube.dev or reach out to maintainers directly in https://slack.cube.dev.
Please do not create issues or public conversations for discovered security issues until patch is shipped.
