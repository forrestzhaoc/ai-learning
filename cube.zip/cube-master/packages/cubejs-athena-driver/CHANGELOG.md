# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.5.16](https://github.com/cube-js/cube/compare/v1.5.15...v1.5.16) (2025-12-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.15](https://github.com/cube-js/cube/compare/v1.5.14...v1.5.15) (2025-12-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.14](https://github.com/cube-js/cube/compare/v1.5.13...v1.5.14) (2025-12-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.13](https://github.com/cube-js/cube/compare/v1.5.12...v1.5.13) (2025-12-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.12](https://github.com/cube-js/cube/compare/v1.5.11...v1.5.12) (2025-12-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.11](https://github.com/cube-js/cube/compare/v1.5.10...v1.5.11) (2025-12-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.10](https://github.com/cube-js/cube/compare/v1.5.9...v1.5.10) (2025-11-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.9](https://github.com/cube-js/cube/compare/v1.5.8...v1.5.9) (2025-11-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.8](https://github.com/cube-js/cube/compare/v1.5.7...v1.5.8) (2025-11-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.7](https://github.com/cube-js/cube/compare/v1.5.6...v1.5.7) (2025-11-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.6](https://github.com/cube-js/cube/compare/v1.5.5...v1.5.6) (2025-11-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.5](https://github.com/cube-js/cube/compare/v1.5.4...v1.5.5) (2025-11-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.4](https://github.com/cube-js/cube/compare/v1.5.3...v1.5.4) (2025-11-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.3](https://github.com/cube-js/cube/compare/v1.5.2...v1.5.3) (2025-11-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.2](https://github.com/cube-js/cube/compare/v1.5.1...v1.5.2) (2025-11-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.5.1](https://github.com/cube-js/cube/compare/v1.5.0...v1.5.1) (2025-11-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [1.5.0](https://github.com/cube-js/cube/compare/v1.4.0...v1.5.0) (2025-10-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [1.4.0](https://github.com/cube-js/cube/compare/v1.3.86...v1.4.0) (2025-10-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.86](https://github.com/cube-js/cube/compare/v1.3.85...v1.3.86) (2025-10-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.85](https://github.com/cube-js/cube/compare/v1.3.84...v1.3.85) (2025-10-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.84](https://github.com/cube-js/cube/compare/v1.3.83...v1.3.84) (2025-10-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.83](https://github.com/cube-js/cube/compare/v1.3.82...v1.3.83) (2025-10-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.82](https://github.com/cube-js/cube/compare/v1.3.81...v1.3.82) (2025-10-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.81](https://github.com/cube-js/cube/compare/v1.3.80...v1.3.81) (2025-10-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.80](https://github.com/cube-js/cube/compare/v1.3.79...v1.3.80) (2025-10-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.79](https://github.com/cube-js/cube/compare/v1.3.78...v1.3.79) (2025-10-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.78](https://github.com/cube-js/cube/compare/v1.3.77...v1.3.78) (2025-10-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.77](https://github.com/cube-js/cube/compare/v1.3.76...v1.3.77) (2025-10-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.76](https://github.com/cube-js/cube/compare/v1.3.75...v1.3.76) (2025-10-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.75](https://github.com/cube-js/cube/compare/v1.3.74...v1.3.75) (2025-09-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.74](https://github.com/cube-js/cube/compare/v1.3.73...v1.3.74) (2025-09-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.73](https://github.com/cube-js/cube/compare/v1.3.72...v1.3.73) (2025-09-25)

### Bug Fixes

- **cubestore:** Disable quoting in csv parser for Athena ([#9997](https://github.com/cube-js/cube/issues/9997)) ([5cefd96](https://github.com/cube-js/cube/commit/5cefd96e71e2e16bfbeda75e1be5c72552414a4a))

## [1.3.72](https://github.com/cube-js/cube/compare/v1.3.71...v1.3.72) (2025-09-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.71](https://github.com/cube-js/cube/compare/v1.3.70...v1.3.71) (2025-09-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.70](https://github.com/cube-js/cube/compare/v1.3.69...v1.3.70) (2025-09-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.69](https://github.com/cube-js/cube/compare/v1.3.68...v1.3.69) (2025-09-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.68](https://github.com/cube-js/cube/compare/v1.3.67...v1.3.68) (2025-09-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.67](https://github.com/cube-js/cube/compare/v1.3.66...v1.3.67) (2025-09-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.66](https://github.com/cube-js/cube/compare/v1.3.65...v1.3.66) (2025-09-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.65](https://github.com/cube-js/cube/compare/v1.3.64...v1.3.65) (2025-09-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.64](https://github.com/cube-js/cube/compare/v1.3.63...v1.3.64) (2025-09-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.63](https://github.com/cube-js/cube/compare/v1.3.62...v1.3.63) (2025-09-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.62](https://github.com/cube-js/cube/compare/v1.3.61...v1.3.62) (2025-08-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.61](https://github.com/cube-js/cube/compare/v1.3.60...v1.3.61) (2025-08-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.60](https://github.com/cube-js/cube/compare/v1.3.59...v1.3.60) (2025-08-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.59](https://github.com/cube-js/cube/compare/v1.3.58...v1.3.59) (2025-08-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.58](https://github.com/cube-js/cube/compare/v1.3.57...v1.3.58) (2025-08-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.57](https://github.com/cube-js/cube/compare/v1.3.56...v1.3.57) (2025-08-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.56](https://github.com/cube-js/cube/compare/v1.3.55...v1.3.56) (2025-08-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.55](https://github.com/cube-js/cube/compare/v1.3.54...v1.3.55) (2025-08-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.54](https://github.com/cube-js/cube/compare/v1.3.53...v1.3.54) (2025-08-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.53](https://github.com/cube-js/cube/compare/v1.3.52...v1.3.53) (2025-08-15)

### Features

- **athena-driver:** export env variables for IAM assume role auth ([#9882](https://github.com/cube-js/cube/issues/9882)) ([3c6fc89](https://github.com/cube-js/cube/commit/3c6fc89dcabe651d83599e7568f571c841ee8bbb))

## [1.3.52](https://github.com/cube-js/cube/compare/v1.3.51...v1.3.52) (2025-08-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.51](https://github.com/cube-js/cube/compare/v1.3.50...v1.3.51) (2025-08-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.50](https://github.com/cube-js/cube/compare/v1.3.49...v1.3.50) (2025-08-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.49](https://github.com/cube-js/cube/compare/v1.3.48...v1.3.49) (2025-08-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.48](https://github.com/cube-js/cube/compare/v1.3.47...v1.3.48) (2025-08-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.47](https://github.com/cube-js/cube/compare/v1.3.46...v1.3.47) (2025-08-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.46](https://github.com/cube-js/cube/compare/v1.3.45...v1.3.46) (2025-07-31)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.45](https://github.com/cube-js/cube/compare/v1.3.44...v1.3.45) (2025-07-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.44](https://github.com/cube-js/cube/compare/v1.3.43...v1.3.44) (2025-07-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.43](https://github.com/cube-js/cube/compare/v1.3.42...v1.3.43) (2025-07-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.42](https://github.com/cube-js/cube/compare/v1.3.41...v1.3.42) (2025-07-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.41](https://github.com/cube-js/cube/compare/v1.3.40...v1.3.41) (2025-07-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.40](https://github.com/cube-js/cube/compare/v1.3.39...v1.3.40) (2025-07-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.39](https://github.com/cube-js/cube/compare/v1.3.38...v1.3.39) (2025-07-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.38](https://github.com/cube-js/cube/compare/v1.3.37...v1.3.38) (2025-07-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.37](https://github.com/cube-js/cube/compare/v1.3.36...v1.3.37) (2025-07-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.36](https://github.com/cube-js/cube/compare/v1.3.35...v1.3.36) (2025-07-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.35](https://github.com/cube-js/cube/compare/v1.3.34...v1.3.35) (2025-07-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.34](https://github.com/cube-js/cube/compare/v1.3.33...v1.3.34) (2025-07-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.33](https://github.com/cube-js/cube/compare/v1.3.32...v1.3.33) (2025-07-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.32](https://github.com/cube-js/cube/compare/v1.3.31...v1.3.32) (2025-07-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.31](https://github.com/cube-js/cube/compare/v1.3.30...v1.3.31) (2025-07-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.30](https://github.com/cube-js/cube/compare/v1.3.29...v1.3.30) (2025-07-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.29](https://github.com/cube-js/cube/compare/v1.3.28...v1.3.29) (2025-07-01)

### Features

- **athena-driver:** Add option for providing default database to use ([#9735](https://github.com/cube-js/cube/issues/9735)) ([834d381](https://github.com/cube-js/cube/commit/834d3815fe6c5228ea5f1ea768027309957524d1))

## [1.3.28](https://github.com/cube-js/cube/compare/v1.3.27...v1.3.28) (2025-06-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.27](https://github.com/cube-js/cube/compare/v1.3.26...v1.3.27) (2025-06-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.26](https://github.com/cube-js/cube/compare/v1.3.25...v1.3.26) (2025-06-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.25](https://github.com/cube-js/cube/compare/v1.3.24...v1.3.25) (2025-06-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.24](https://github.com/cube-js/cube/compare/v1.3.23...v1.3.24) (2025-06-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.23](https://github.com/cube-js/cube/compare/v1.3.22...v1.3.23) (2025-06-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.22](https://github.com/cube-js/cube/compare/v1.3.21...v1.3.22) (2025-06-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.21](https://github.com/cube-js/cube/compare/v1.3.20...v1.3.21) (2025-06-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.20](https://github.com/cube-js/cube/compare/v1.3.19...v1.3.20) (2025-06-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.19](https://github.com/cube-js/cube/compare/v1.3.18...v1.3.19) (2025-06-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.18](https://github.com/cube-js/cube/compare/v1.3.17...v1.3.18) (2025-05-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.17](https://github.com/cube-js/cube/compare/v1.3.16...v1.3.17) (2025-05-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.16](https://github.com/cube-js/cube/compare/v1.3.15...v1.3.16) (2025-05-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.15](https://github.com/cube-js/cube/compare/v1.3.14...v1.3.15) (2025-05-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.14](https://github.com/cube-js/cube/compare/v1.3.13...v1.3.14) (2025-05-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.13](https://github.com/cube-js/cube/compare/v1.3.12...v1.3.13) (2025-05-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.12](https://github.com/cube-js/cube/compare/v1.3.11...v1.3.12) (2025-05-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.11](https://github.com/cube-js/cube/compare/v1.3.10...v1.3.11) (2025-05-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.10](https://github.com/cube-js/cube/compare/v1.3.9...v1.3.10) (2025-05-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.9](https://github.com/cube-js/cube/compare/v1.3.8...v1.3.9) (2025-04-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.8](https://github.com/cube-js/cube/compare/v1.3.7...v1.3.8) (2025-04-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.7](https://github.com/cube-js/cube/compare/v1.3.6...v1.3.7) (2025-04-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.6](https://github.com/cube-js/cube/compare/v1.3.5...v1.3.6) (2025-04-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.5](https://github.com/cube-js/cube/compare/v1.3.4...v1.3.5) (2025-04-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.4](https://github.com/cube-js/cube/compare/v1.3.3...v1.3.4) (2025-04-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.3](https://github.com/cube-js/cube/compare/v1.3.2...v1.3.3) (2025-04-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.2](https://github.com/cube-js/cube/compare/v1.3.1...v1.3.2) (2025-04-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.3.1](https://github.com/cube-js/cube/compare/v1.3.0...v1.3.1) (2025-04-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [1.3.0](https://github.com/cube-js/cube/compare/v1.2.33...v1.3.0) (2025-04-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.33](https://github.com/cube-js/cube/compare/v1.2.32...v1.2.33) (2025-04-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.32](https://github.com/cube-js/cube/compare/v1.2.31...v1.2.32) (2025-04-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.31](https://github.com/cube-js/cube/compare/v1.2.30...v1.2.31) (2025-04-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.30](https://github.com/cube-js/cube/compare/v1.2.29...v1.2.30) (2025-04-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.29](https://github.com/cube-js/cube/compare/v1.2.28...v1.2.29) (2025-04-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.28](https://github.com/cube-js/cube/compare/v1.2.27...v1.2.28) (2025-04-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.27](https://github.com/cube-js/cube/compare/v1.2.26...v1.2.27) (2025-03-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.26](https://github.com/cube-js/cube/compare/v1.2.25...v1.2.26) (2025-03-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.25](https://github.com/cube-js/cube/compare/v1.2.24...v1.2.25) (2025-03-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.24](https://github.com/cube-js/cube/compare/v1.2.23...v1.2.24) (2025-03-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.23](https://github.com/cube-js/cube/compare/v1.2.22...v1.2.23) (2025-03-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.22](https://github.com/cube-js/cube/compare/v1.2.21...v1.2.22) (2025-03-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.21](https://github.com/cube-js/cube/compare/v1.2.20...v1.2.21) (2025-03-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.20](https://github.com/cube-js/cube/compare/v1.2.19...v1.2.20) (2025-03-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.19](https://github.com/cube-js/cube/compare/v1.2.18...v1.2.19) (2025-03-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.18](https://github.com/cube-js/cube/compare/v1.2.17...v1.2.18) (2025-03-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.17](https://github.com/cube-js/cube/compare/v1.2.16...v1.2.17) (2025-03-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.16](https://github.com/cube-js/cube/compare/v1.2.15...v1.2.16) (2025-03-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.15](https://github.com/cube-js/cube/compare/v1.2.14...v1.2.15) (2025-03-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.14](https://github.com/cube-js/cube/compare/v1.2.13...v1.2.14) (2025-02-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.13](https://github.com/cube-js/cube/compare/v1.2.12...v1.2.13) (2025-02-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.12](https://github.com/cube-js/cube/compare/v1.2.11...v1.2.12) (2025-02-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.11](https://github.com/cube-js/cube/compare/v1.2.10...v1.2.11) (2025-02-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.10](https://github.com/cube-js/cube/compare/v1.2.9...v1.2.10) (2025-02-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.9](https://github.com/cube-js/cube/compare/v1.2.8...v1.2.9) (2025-02-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.8](https://github.com/cube-js/cube/compare/v1.2.7...v1.2.8) (2025-02-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.7](https://github.com/cube-js/cube/compare/v1.2.6...v1.2.7) (2025-02-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.6](https://github.com/cube-js/cube/compare/v1.2.5...v1.2.6) (2025-02-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.5](https://github.com/cube-js/cube/compare/v1.2.4...v1.2.5) (2025-02-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.4](https://github.com/cube-js/cube/compare/v1.2.3...v1.2.4) (2025-02-11)

### Features

- **server-core:** Introduce CUBEJS_REFRESH_WORKER_CONCURRENCY env and update default concurrency settings for drivers ([#9168](https://github.com/cube-js/cube/issues/9168)) ([7ef6282](https://github.com/cube-js/cube/commit/7ef628273905d47996b108862a52dde89b9525e3))

## [1.2.3](https://github.com/cube-js/cube/compare/v1.2.2...v1.2.3) (2025-02-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.2](https://github.com/cube-js/cube/compare/v1.2.1...v1.2.2) (2025-02-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.2.1](https://github.com/cube-js/cube/compare/v1.2.0...v1.2.1) (2025-02-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [1.2.0](https://github.com/cube-js/cube/compare/v1.1.18...v1.2.0) (2025-02-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.17](https://github.com/cube-js/cube/compare/v1.1.16...v1.1.17) (2025-01-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.16](https://github.com/cube-js/cube/compare/v1.1.15...v1.1.16) (2025-01-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.15](https://github.com/cube-js/cube/compare/v1.1.14...v1.1.15) (2025-01-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.14](https://github.com/cube-js/cube/compare/v1.1.13...v1.1.14) (2025-01-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.13](https://github.com/cube-js/cube/compare/v1.1.12...v1.1.13) (2025-01-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.12](https://github.com/cube-js/cube/compare/v1.1.11...v1.1.12) (2025-01-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.11](https://github.com/cube-js/cube/compare/v1.1.10...v1.1.11) (2024-12-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.10](https://github.com/cube-js/cube/compare/v1.1.9...v1.1.10) (2024-12-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.9](https://github.com/cube-js/cube/compare/v1.1.8...v1.1.9) (2024-12-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.8](https://github.com/cube-js/cube/compare/v1.1.7...v1.1.8) (2024-12-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.7](https://github.com/cube-js/cube/compare/v1.1.6...v1.1.7) (2024-11-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.6](https://github.com/cube-js/cube/compare/v1.1.5...v1.1.6) (2024-11-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.5](https://github.com/cube-js/cube/compare/v1.1.4...v1.1.5) (2024-11-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.4](https://github.com/cube-js/cube/compare/v1.1.3...v1.1.4) (2024-11-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.3](https://github.com/cube-js/cube/compare/v1.1.2...v1.1.3) (2024-11-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.2](https://github.com/cube-js/cube/compare/v1.1.1...v1.1.2) (2024-11-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.1.1](https://github.com/cube-js/cube/compare/v1.1.0...v1.1.1) (2024-10-31)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [1.1.0](https://github.com/cube-js/cube/compare/v1.0.4...v1.1.0) (2024-10-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.0.4](https://github.com/cube-js/cube/compare/v1.0.3...v1.0.4) (2024-10-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.0.3](https://github.com/cube-js/cube/compare/v1.0.2...v1.0.3) (2024-10-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.0.2](https://github.com/cube-js/cube/compare/v1.0.1...v1.0.2) (2024-10-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [1.0.1](https://github.com/cube-js/cube/compare/v1.0.0...v1.0.1) (2024-10-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [1.0.0](https://github.com/cube-js/cube/compare/v0.36.11...v1.0.0) (2024-10-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.36.11](https://github.com/cube-js/cube/compare/v0.36.10...v0.36.11) (2024-10-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.36.10](https://github.com/cube-js/cube/compare/v0.36.9...v0.36.10) (2024-10-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.36.9](https://github.com/cube-js/cube/compare/v0.36.8...v0.36.9) (2024-10-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.36.8](https://github.com/cube-js/cube/compare/v0.36.7...v0.36.8) (2024-10-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.36.7](https://github.com/cube-js/cube/compare/v0.36.6...v0.36.7) (2024-10-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.36.6](https://github.com/cube-js/cube/compare/v0.36.5...v0.36.6) (2024-10-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.36.5](https://github.com/cube-js/cube/compare/v0.36.4...v0.36.5) (2024-10-02)

### Features

- **snowflake-driver:** support azure exports buckets ([#8730](https://github.com/cube-js/cube/issues/8730)) ([37c6ccc](https://github.com/cube-js/cube/commit/37c6cccc7a3b0617d87bcc6775d63f501074b737))

## [0.36.4](https://github.com/cube-js/cube/compare/v0.36.3...v0.36.4) (2024-09-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.36.3](https://github.com/cube-js/cube/compare/v0.36.2...v0.36.3) (2024-09-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.36.2](https://github.com/cube-js/cube/compare/v0.36.1...v0.36.2) (2024-09-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.36.1](https://github.com/cube-js/cube/compare/v0.36.0...v0.36.1) (2024-09-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.36.0](https://github.com/cube-js/cube/compare/v0.35.81...v0.36.0) (2024-09-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.81](https://github.com/cube-js/cube/compare/v0.35.80...v0.35.81) (2024-09-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.80](https://github.com/cube-js/cube/compare/v0.35.79...v0.35.80) (2024-09-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.79](https://github.com/cube-js/cube/compare/v0.35.78...v0.35.79) (2024-09-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.78](https://github.com/cube-js/cube/compare/v0.35.77...v0.35.78) (2024-08-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.77](https://github.com/cube-js/cube/compare/v0.35.76...v0.35.77) (2024-08-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.76](https://github.com/cube-js/cube/compare/v0.35.75...v0.35.76) (2024-08-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.75](https://github.com/cube-js/cube/compare/v0.35.74...v0.35.75) (2024-08-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.74](https://github.com/cube-js/cube/compare/v0.35.73...v0.35.74) (2024-08-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.73](https://github.com/cube-js/cube/compare/v0.35.72...v0.35.73) (2024-08-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.72](https://github.com/cube-js/cube/compare/v0.35.71...v0.35.72) (2024-08-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.71](https://github.com/cube-js/cube/compare/v0.35.70...v0.35.71) (2024-08-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.70](https://github.com/cube-js/cube/compare/v0.35.69...v0.35.70) (2024-08-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.69](https://github.com/cube-js/cube/compare/v0.35.68...v0.35.69) (2024-08-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.68](https://github.com/cube-js/cube/compare/v0.35.67...v0.35.68) (2024-08-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.67](https://github.com/cube-js/cube/compare/v0.35.66...v0.35.67) (2024-08-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.66](https://github.com/cube-js/cube/compare/v0.35.65...v0.35.66) (2024-08-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.65](https://github.com/cube-js/cube/compare/v0.35.64...v0.35.65) (2024-07-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.64](https://github.com/cube-js/cube/compare/v0.35.63...v0.35.64) (2024-07-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.63](https://github.com/cube-js/cube/compare/v0.35.62...v0.35.63) (2024-07-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.62](https://github.com/cube-js/cube/compare/v0.35.61...v0.35.62) (2024-07-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.61](https://github.com/cube-js/cube/compare/v0.35.60...v0.35.61) (2024-07-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.60](https://github.com/cube-js/cube/compare/v0.35.59...v0.35.60) (2024-07-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.59](https://github.com/cube-js/cube/compare/v0.35.58...v0.35.59) (2024-07-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.58](https://github.com/cube-js/cube/compare/v0.35.57...v0.35.58) (2024-07-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.57](https://github.com/cube-js/cube/compare/v0.35.56...v0.35.57) (2024-07-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.56](https://github.com/cube-js/cube/compare/v0.35.55...v0.35.56) (2024-07-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.55](https://github.com/cube-js/cube/compare/v0.35.54...v0.35.55) (2024-06-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.54](https://github.com/cube-js/cube/compare/v0.35.53...v0.35.54) (2024-06-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.53](https://github.com/cube-js/cube/compare/v0.35.52...v0.35.53) (2024-06-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.52](https://github.com/cube-js/cube/compare/v0.35.51...v0.35.52) (2024-06-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.51](https://github.com/cube-js/cube/compare/v0.35.50...v0.35.51) (2024-06-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.50](https://github.com/cube-js/cube/compare/v0.35.49...v0.35.50) (2024-06-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.49](https://github.com/cube-js/cube/compare/v0.35.48...v0.35.49) (2024-06-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.48](https://github.com/cube-js/cube/compare/v0.35.47...v0.35.48) (2024-06-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.47](https://github.com/cube-js/cube/compare/v0.35.46...v0.35.47) (2024-06-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.46](https://github.com/cube-js/cube/compare/v0.35.45...v0.35.46) (2024-06-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.45](https://github.com/cube-js/cube/compare/v0.35.44...v0.35.45) (2024-06-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.44](https://github.com/cube-js/cube/compare/v0.35.43...v0.35.44) (2024-06-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.43](https://github.com/cube-js/cube/compare/v0.35.42...v0.35.43) (2024-05-31)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.42](https://github.com/cube-js/cube/compare/v0.35.41...v0.35.42) (2024-05-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.40](https://github.com/cube-js/cube/compare/v0.35.39...v0.35.40) (2024-05-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.39](https://github.com/cube-js/cube/compare/v0.35.38...v0.35.39) (2024-05-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.38](https://github.com/cube-js/cube/compare/v0.35.37...v0.35.38) (2024-05-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.37](https://github.com/cube-js/cube/compare/v0.35.36...v0.35.37) (2024-05-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.36](https://github.com/cube-js/cube/compare/v0.35.35...v0.35.36) (2024-05-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.35](https://github.com/cube-js/cube/compare/v0.35.34...v0.35.35) (2024-05-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.34](https://github.com/cube-js/cube/compare/v0.35.33...v0.35.34) (2024-05-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.33](https://github.com/cube-js/cube/compare/v0.35.32...v0.35.33) (2024-05-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.32](https://github.com/cube-js/cube/compare/v0.35.31...v0.35.32) (2024-05-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.31](https://github.com/cube-js/cube/compare/v0.35.30...v0.35.31) (2024-05-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.30](https://github.com/cube-js/cube/compare/v0.35.29...v0.35.30) (2024-05-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.29](https://github.com/cube-js/cube/compare/v0.35.28...v0.35.29) (2024-05-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.28](https://github.com/cube-js/cube/compare/v0.35.27...v0.35.28) (2024-05-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.27](https://github.com/cube-js/cube/compare/v0.35.26...v0.35.27) (2024-05-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.26](https://github.com/cube-js/cube/compare/v0.35.25...v0.35.26) (2024-05-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.25](https://github.com/cube-js/cube/compare/v0.35.24...v0.35.25) (2024-04-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.24](https://github.com/cube-js/cube/compare/v0.35.23...v0.35.24) (2024-04-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.23](https://github.com/cube-js/cube/compare/v0.35.22...v0.35.23) (2024-04-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.22](https://github.com/cube-js/cube/compare/v0.35.21...v0.35.22) (2024-04-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.21](https://github.com/cube-js/cube/compare/v0.35.20...v0.35.21) (2024-04-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.20](https://github.com/cube-js/cube/compare/v0.35.19...v0.35.20) (2024-04-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.19](https://github.com/cube-js/cube/compare/v0.35.18...v0.35.19) (2024-04-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.18](https://github.com/cube-js/cube/compare/v0.35.17...v0.35.18) (2024-04-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.17](https://github.com/cube-js/cube/compare/v0.35.16...v0.35.17) (2024-04-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.16](https://github.com/cube-js/cube/compare/v0.35.15...v0.35.16) (2024-04-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.15](https://github.com/cube-js/cube/compare/v0.35.14...v0.35.15) (2024-04-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.14](https://github.com/cube-js/cube/compare/v0.35.13...v0.35.14) (2024-04-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.13](https://github.com/cube-js/cube/compare/v0.35.12...v0.35.13) (2024-04-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.11](https://github.com/cube-js/cube/compare/v0.35.10...v0.35.11) (2024-04-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.10](https://github.com/cube-js/cube/compare/v0.35.9...v0.35.10) (2024-04-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.9](https://github.com/cube-js/cube/compare/v0.35.8...v0.35.9) (2024-04-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.8](https://github.com/cube-js/cube/compare/v0.35.7...v0.35.8) (2024-04-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.7](https://github.com/cube-js/cube/compare/v0.35.6...v0.35.7) (2024-04-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.6](https://github.com/cube-js/cube/compare/v0.35.5...v0.35.6) (2024-04-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.5](https://github.com/cube-js/cube/compare/v0.35.4...v0.35.5) (2024-03-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.4](https://github.com/cube-js/cube/compare/v0.35.3...v0.35.4) (2024-03-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.3](https://github.com/cube-js/cube/compare/v0.35.2...v0.35.3) (2024-03-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.2](https://github.com/cube-js/cube/compare/v0.35.1...v0.35.2) (2024-03-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.35.1](https://github.com/cube-js/cube/compare/v0.35.0...v0.35.1) (2024-03-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.35.0](https://github.com/cube-js/cube/compare/v0.34.62...v0.35.0) (2024-03-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.62](https://github.com/cube-js/cube/compare/v0.34.61...v0.34.62) (2024-03-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.61](https://github.com/cube-js/cube/compare/v0.34.60...v0.34.61) (2024-03-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.60](https://github.com/cube-js/cube/compare/v0.34.59...v0.34.60) (2024-03-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.59](https://github.com/cube-js/cube/compare/v0.34.58...v0.34.59) (2024-02-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.58](https://github.com/cube-js/cube/compare/v0.34.57...v0.34.58) (2024-02-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.57](https://github.com/cube-js/cube/compare/v0.34.56...v0.34.57) (2024-02-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.56](https://github.com/cube-js/cube/compare/v0.34.55...v0.34.56) (2024-02-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.55](https://github.com/cube-js/cube/compare/v0.34.54...v0.34.55) (2024-02-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.54](https://github.com/cube-js/cube/compare/v0.34.53...v0.34.54) (2024-02-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.53](https://github.com/cube-js/cube/compare/v0.34.52...v0.34.53) (2024-02-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.52](https://github.com/cube-js/cube/compare/v0.34.51...v0.34.52) (2024-02-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.51](https://github.com/cube-js/cube/compare/v0.34.50...v0.34.51) (2024-02-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.50](https://github.com/cube-js/cube/compare/v0.34.49...v0.34.50) (2024-01-31)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.49](https://github.com/cube-js/cube/compare/v0.34.48...v0.34.49) (2024-01-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.48](https://github.com/cube-js/cube/compare/v0.34.47...v0.34.48) (2024-01-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.47](https://github.com/cube-js/cube/compare/v0.34.46...v0.34.47) (2024-01-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.46](https://github.com/cube-js/cube/compare/v0.34.45...v0.34.46) (2024-01-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.45](https://github.com/cube-js/cube/compare/v0.34.44...v0.34.45) (2024-01-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.44](https://github.com/cube-js/cube/compare/v0.34.43...v0.34.44) (2024-01-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.43](https://github.com/cube-js/cube/compare/v0.34.42...v0.34.43) (2024-01-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.42](https://github.com/cube-js/cube/compare/v0.34.41...v0.34.42) (2024-01-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.41](https://github.com/cube-js/cube/compare/v0.34.40...v0.34.41) (2024-01-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.40](https://github.com/cube-js/cube/compare/v0.34.39...v0.34.40) (2023-12-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.39](https://github.com/cube-js/cube/compare/v0.34.38...v0.34.39) (2023-12-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.38](https://github.com/cube-js/cube/compare/v0.34.37...v0.34.38) (2023-12-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.37](https://github.com/cube-js/cube/compare/v0.34.36...v0.34.37) (2023-12-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.36](https://github.com/cube-js/cube/compare/v0.34.35...v0.34.36) (2023-12-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.35](https://github.com/cube-js/cube/compare/v0.34.34...v0.34.35) (2023-12-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.33](https://github.com/cube-js/cube/compare/v0.34.32...v0.34.33) (2023-12-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.32](https://github.com/cube-js/cube/compare/v0.34.31...v0.34.32) (2023-12-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.31](https://github.com/cube-js/cube/compare/v0.34.30...v0.34.31) (2023-12-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.30](https://github.com/cube-js/cube/compare/v0.34.29...v0.34.30) (2023-12-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.29](https://github.com/cube-js/cube/compare/v0.34.28...v0.34.29) (2023-12-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.27](https://github.com/cube-js/cube/compare/v0.34.26...v0.34.27) (2023-11-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.26](https://github.com/cube-js/cube/compare/v0.34.25...v0.34.26) (2023-11-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.25](https://github.com/cube-js/cube/compare/v0.34.24...v0.34.25) (2023-11-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.24](https://github.com/cube-js/cube/compare/v0.34.23...v0.34.24) (2023-11-23)

### Bug Fixes

- **athena-driver:** Allow to pass custom credentials, fix [#7407](https://github.com/cube-js/cube/issues/7407) ([#7429](https://github.com/cube-js/cube/issues/7429)) ([f005c5b](https://github.com/cube-js/cube/commit/f005c5b88418c1c9e34f476c25e523f64434c9ca))

## [0.34.23](https://github.com/cube-js/cube/compare/v0.34.22...v0.34.23) (2023-11-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.22](https://github.com/cube-js/cube/compare/v0.34.21...v0.34.22) (2023-11-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.21](https://github.com/cube-js/cube/compare/v0.34.20...v0.34.21) (2023-11-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.20](https://github.com/cube-js/cube/compare/v0.34.19...v0.34.20) (2023-11-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.19](https://github.com/cube-js/cube/compare/v0.34.18...v0.34.19) (2023-11-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.18](https://github.com/cube-js/cube/compare/v0.34.17...v0.34.18) (2023-11-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.17](https://github.com/cube-js/cube/compare/v0.34.16...v0.34.17) (2023-11-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.16](https://github.com/cube-js/cube/compare/v0.34.15...v0.34.16) (2023-11-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.15](https://github.com/cube-js/cube/compare/v0.34.14...v0.34.15) (2023-11-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.14](https://github.com/cube-js/cube/compare/v0.34.13...v0.34.14) (2023-11-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.13](https://github.com/cube-js/cube/compare/v0.34.12...v0.34.13) (2023-10-31)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.12](https://github.com/cube-js/cube/compare/v0.34.11...v0.34.12) (2023-10-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.11](https://github.com/cube-js/cube/compare/v0.34.10...v0.34.11) (2023-10-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.10](https://github.com/cube-js/cube/compare/v0.34.9...v0.34.10) (2023-10-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.9](https://github.com/cube-js/cube/compare/v0.34.8...v0.34.9) (2023-10-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.8](https://github.com/cube-js/cube/compare/v0.34.7...v0.34.8) (2023-10-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.7](https://github.com/cube-js/cube/compare/v0.34.6...v0.34.7) (2023-10-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.6](https://github.com/cube-js/cube/compare/v0.34.5...v0.34.6) (2023-10-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.5](https://github.com/cube-js/cube/compare/v0.34.4...v0.34.5) (2023-10-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.4](https://github.com/cube-js/cube/compare/v0.34.3...v0.34.4) (2023-10-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.3](https://github.com/cube-js/cube/compare/v0.34.2...v0.34.3) (2023-10-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.2](https://github.com/cube-js/cube/compare/v0.34.1...v0.34.2) (2023-10-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.34.1](https://github.com/cube-js/cube/compare/v0.34.0...v0.34.1) (2023-10-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.34.0](https://github.com/cube-js/cube/compare/v0.33.65...v0.34.0) (2023-10-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.65](https://github.com/cube-js/cube/compare/v0.33.64...v0.33.65) (2023-10-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.64](https://github.com/cube-js/cube/compare/v0.33.63...v0.33.64) (2023-09-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.63](https://github.com/cube-js/cube/compare/v0.33.62...v0.33.63) (2023-09-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.62](https://github.com/cube-js/cube/compare/v0.33.61...v0.33.62) (2023-09-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.61](https://github.com/cube-js/cube/compare/v0.33.60...v0.33.61) (2023-09-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.60](https://github.com/cube-js/cube/compare/v0.33.59...v0.33.60) (2023-09-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.59](https://github.com/cube-js/cube/compare/v0.33.58...v0.33.59) (2023-09-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.58](https://github.com/cube-js/cube/compare/v0.33.57...v0.33.58) (2023-09-18)

### Features

- new methods for step-by-step db schema fetching ([#7058](https://github.com/cube-js/cube/issues/7058)) ([a362c20](https://github.com/cube-js/cube/commit/a362c2042d4158ae735e9afe0cfeae15c331dc9d))

## [0.33.57](https://github.com/cube-js/cube/compare/v0.33.56...v0.33.57) (2023-09-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.56](https://github.com/cube-js/cube/compare/v0.33.55...v0.33.56) (2023-09-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.55](https://github.com/cube-js/cube/compare/v0.33.54...v0.33.55) (2023-09-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.54](https://github.com/cube-js/cube/compare/v0.33.53...v0.33.54) (2023-09-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.53](https://github.com/cube-js/cube/compare/v0.33.52...v0.33.53) (2023-09-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.51](https://github.com/cube-js/cube/compare/v0.33.50...v0.33.51) (2023-09-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.50](https://github.com/cube-js/cube/compare/v0.33.49...v0.33.50) (2023-09-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.49](https://github.com/cube-js/cube/compare/v0.33.48...v0.33.49) (2023-08-31)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.48](https://github.com/cube-js/cube/compare/v0.33.47...v0.33.48) (2023-08-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.47](https://github.com/cube-js/cube/compare/v0.33.46...v0.33.47) (2023-08-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.46](https://github.com/cube-js/cube/compare/v0.33.45...v0.33.46) (2023-08-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.45](https://github.com/cube-js/cube/compare/v0.33.44...v0.33.45) (2023-08-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.44](https://github.com/cube-js/cube/compare/v0.33.43...v0.33.44) (2023-08-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.43](https://github.com/cube-js/cube/compare/v0.33.42...v0.33.43) (2023-08-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.42](https://github.com/cube-js/cube/compare/v0.33.41...v0.33.42) (2023-08-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.41](https://github.com/cube-js/cube/compare/v0.33.40...v0.33.41) (2023-07-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.40](https://github.com/cube-js/cube/compare/v0.33.39...v0.33.40) (2023-07-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.39](https://github.com/cube-js/cube/compare/v0.33.38...v0.33.39) (2023-07-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.38](https://github.com/cube-js/cube/compare/v0.33.37...v0.33.38) (2023-07-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.37](https://github.com/cube-js/cube/compare/v0.33.36...v0.33.37) (2023-07-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.36](https://github.com/cube-js/cube/compare/v0.33.35...v0.33.36) (2023-07-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.34](https://github.com/cube-js/cube/compare/v0.33.33...v0.33.34) (2023-07-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.33](https://github.com/cube-js/cube/compare/v0.33.32...v0.33.33) (2023-07-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.32](https://github.com/cube-js/cube/compare/v0.33.31...v0.33.32) (2023-07-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.31](https://github.com/cube-js/cube/compare/v0.33.30...v0.33.31) (2023-07-01)

### Bug Fixes

- **databricks-jdbc-driver:** Return NULL decimal as NULL instead of 0 ([#6768](https://github.com/cube-js/cube/issues/6768)) ([c2ab19d](https://github.com/cube-js/cube/commit/c2ab19d86d6144e4f91f9e8fb681e17e87bfcef3))

## [0.33.29](https://github.com/cube-js/cube/compare/v0.33.28...v0.33.29) (2023-06-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.28](https://github.com/cube-js/cube/compare/v0.33.27...v0.33.28) (2023-06-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.27](https://github.com/cube-js/cube/compare/v0.33.26...v0.33.27) (2023-06-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.26](https://github.com/cube-js/cube/compare/v0.33.25...v0.33.26) (2023-06-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.25](https://github.com/cube-js/cube/compare/v0.33.24...v0.33.25) (2023-06-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.24](https://github.com/cube-js/cube/compare/v0.33.23...v0.33.24) (2023-06-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.21](https://github.com/cube-js/cube/compare/v0.33.20...v0.33.21) (2023-05-31)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.20](https://github.com/cube-js/cube/compare/v0.33.19...v0.33.20) (2023-05-31)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.19](https://github.com/cube-js/cube/compare/v0.33.18...v0.33.19) (2023-05-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.18](https://github.com/cube-js/cube/compare/v0.33.17...v0.33.18) (2023-05-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.15](https://github.com/cube-js/cube/compare/v0.33.14...v0.33.15) (2023-05-26)

### Bug Fixes

- **athena-driver:** Internal: Error during planning: Coercion from [Utf8, Utf8] to the signature Exact([Utf8, Timestamp(Nanosecond, None)]) failed for athena pre-aggregations ([#6655](https://github.com/cube-js/cube/issues/6655)) ([46f7dbd](https://github.com/cube-js/cube/commit/46f7dbdeb0a9f55640d0f7afd7edb67ec101a43a))

## [0.33.13](https://github.com/cube-js/cube/compare/v0.33.12...v0.33.13) (2023-05-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.11](https://github.com/cube-js/cube/compare/v0.33.10...v0.33.11) (2023-05-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.9](https://github.com/cube-js/cube/compare/v0.33.8...v0.33.9) (2023-05-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.8](https://github.com/cube-js/cube/compare/v0.33.7...v0.33.8) (2023-05-17)

### Bug Fixes

- **athena-driver:** Fix partitioned pre-aggregations and column values with `,` through export bucket ([#6596](https://github.com/cube-js/cube/issues/6596)) ([1214cab](https://github.com/cube-js/cube/commit/1214cabf69f9e6216c516d05acadfe7e6178cccf))

## [0.33.7](https://github.com/cube-js/cube/compare/v0.33.6...v0.33.7) (2023-05-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.6](https://github.com/cube-js/cube/compare/v0.33.5...v0.33.6) (2023-05-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.5](https://github.com/cube-js/cube/compare/v0.33.4...v0.33.5) (2023-05-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.4](https://github.com/cube-js/cube/compare/v0.33.3...v0.33.4) (2023-05-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.33.2](https://github.com/cube-js/cube/compare/v0.33.1...v0.33.2) (2023-05-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.33.0](https://github.com/cube-js/cube/compare/v0.32.31...v0.33.0) (2023-05-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.31](https://github.com/cube-js/cube/compare/v0.32.30...v0.32.31) (2023-05-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.30](https://github.com/cube-js/cube/compare/v0.32.29...v0.32.30) (2023-04-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.29](https://github.com/cube-js/cube/compare/v0.32.28...v0.32.29) (2023-04-25)

### Features

- **athena-driver:** read-only unload ([#6469](https://github.com/cube-js/cube/issues/6469)) ([d3fee7c](https://github.com/cube-js/cube/commit/d3fee7cbefe5c415573c4d2507b7e61a48f0c91a))
- **snowflake-driver:** streaming export, read-only unload ([#6452](https://github.com/cube-js/cube/issues/6452)) ([67565b9](https://github.com/cube-js/cube/commit/67565b975c16f93070de0346056c6a3865bc9fd8))

## [0.32.28](https://github.com/cube-js/cube/compare/v0.32.27...v0.32.28) (2023-04-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.27](https://github.com/cube-js/cube/compare/v0.32.26...v0.32.27) (2023-04-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.26](https://github.com/cube-js/cube/compare/v0.32.25...v0.32.26) (2023-04-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.25](https://github.com/cube-js/cube/compare/v0.32.24...v0.32.25) (2023-04-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.23](https://github.com/cube-js/cube/compare/v0.32.22...v0.32.23) (2023-04-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.22](https://github.com/cube-js/cube/compare/v0.32.21...v0.32.22) (2023-04-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.21](https://github.com/cube-js/cube/compare/v0.32.20...v0.32.21) (2023-04-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.20](https://github.com/cube-js/cube/compare/v0.32.19...v0.32.20) (2023-04-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.19](https://github.com/cube-js/cube/compare/v0.32.18...v0.32.19) (2023-04-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.18](https://github.com/cube-js/cube/compare/v0.32.17...v0.32.18) (2023-04-02)

### Bug Fixes

- **athena-driver:** Correct handling for NULL values ([#6171](https://github.com/cube-js/cube/issues/6171)) ([a1f4cd4](https://github.com/cube-js/cube/commit/a1f4cd498e84dde91d736cc87825ae3a8095f9bf))

## [0.32.17](https://github.com/cube-js/cube/compare/v0.32.16...v0.32.17) (2023-03-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.16](https://github.com/cube-js/cube/compare/v0.32.15...v0.32.16) (2023-03-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.15](https://github.com/cube-js/cube/compare/v0.32.14...v0.32.15) (2023-03-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.14](https://github.com/cube-js/cube/compare/v0.32.13...v0.32.14) (2023-03-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.13](https://github.com/cube-js/cube/compare/v0.32.12...v0.32.13) (2023-03-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.12](https://github.com/cube-js/cube/compare/v0.32.11...v0.32.12) (2023-03-22)

### Features

- **cubestore-driver:** Support timestamp(3) as a column type ([#6324](https://github.com/cube-js/cube/issues/6324)) ([71dbca4](https://github.com/cube-js/cube/commit/71dbca4ed1fb706d36af322d2659435465804825))

## [0.32.10](https://github.com/cube-js/cube.js/compare/v0.32.9...v0.32.10) (2023-03-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.8](https://github.com/cube-js/cube.js/compare/v0.32.7...v0.32.8) (2023-03-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.7](https://github.com/cube-js/cube.js/compare/v0.32.6...v0.32.7) (2023-03-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.6](https://github.com/cube-js/cube.js/compare/v0.32.5...v0.32.6) (2023-03-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.5](https://github.com/cube-js/cube.js/compare/v0.32.4...v0.32.5) (2023-03-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.4](https://github.com/cube-js/cube.js/compare/v0.32.3...v0.32.4) (2023-03-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.3](https://github.com/cube-js/cube.js/compare/v0.32.2...v0.32.3) (2023-03-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.32.2](https://github.com/cube-js/cube.js/compare/v0.32.1...v0.32.2) (2023-03-07)

### Features

- connection validation and logging ([#6233](https://github.com/cube-js/cube.js/issues/6233)) ([6dc48f8](https://github.com/cube-js/cube.js/commit/6dc48f8dc8045234dfa9fe8922534c5204e6e569))

## [0.32.1](https://github.com/cube-js/cube.js/compare/v0.32.0...v0.32.1) (2023-03-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.32.0](https://github.com/cube-js/cube.js/compare/v0.31.69...v0.32.0) (2023-03-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.69](https://github.com/cube-js/cube.js/compare/v0.31.68...v0.31.69) (2023-03-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.68](https://github.com/cube-js/cube.js/compare/v0.31.67...v0.31.68) (2023-02-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.67](https://github.com/cube-js/cube.js/compare/v0.31.66...v0.31.67) (2023-02-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.66](https://github.com/cube-js/cube.js/compare/v0.31.65...v0.31.66) (2023-02-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.65](https://github.com/cube-js/cube.js/compare/v0.31.64...v0.31.65) (2023-02-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.64](https://github.com/cube-js/cube.js/compare/v0.31.63...v0.31.64) (2023-02-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.63](https://github.com/cube-js/cube.js/compare/v0.31.62...v0.31.63) (2023-02-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.62](https://github.com/cube-js/cube.js/compare/v0.31.61...v0.31.62) (2023-02-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.60](https://github.com/cube-js/cube.js/compare/v0.31.59...v0.31.60) (2023-02-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.59](https://github.com/cube-js/cube.js/compare/v0.31.58...v0.31.59) (2023-02-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.58](https://github.com/cube-js/cube.js/compare/v0.31.57...v0.31.58) (2023-02-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.57](https://github.com/cube-js/cube.js/compare/v0.31.56...v0.31.57) (2023-02-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.56](https://github.com/cube-js/cube.js/compare/v0.31.55...v0.31.56) (2023-01-31)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.55](https://github.com/cube-js/cube.js/compare/v0.31.54...v0.31.55) (2023-01-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.54](https://github.com/cube-js/cube.js/compare/v0.31.53...v0.31.54) (2023-01-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.53](https://github.com/cube-js/cube.js/compare/v0.31.52...v0.31.53) (2023-01-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.52](https://github.com/cube-js/cube.js/compare/v0.31.51...v0.31.52) (2023-01-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.51](https://github.com/cube-js/cube.js/compare/v0.31.50...v0.31.51) (2023-01-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.50](https://github.com/cube-js/cube.js/compare/v0.31.49...v0.31.50) (2023-01-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.49](https://github.com/cube-js/cube.js/compare/v0.31.48...v0.31.49) (2023-01-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.48](https://github.com/cube-js/cube.js/compare/v0.31.47...v0.31.48) (2023-01-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.47](https://github.com/cube-js/cube.js/compare/v0.31.46...v0.31.47) (2023-01-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.46](https://github.com/cube-js/cube.js/compare/v0.31.45...v0.31.46) (2023-01-18)

### Bug Fixes

- **athena-driver:** Help user to understand CUBEJS_AWS_S3_OUTPUT_LOCATION parameter is missing ([#5991](https://github.com/cube-js/cube.js/issues/5991)) Thanks [@fbalicchia](https://github.com/fbalicchia) ! ([eedd12a](https://github.com/cube-js/cube.js/commit/eedd12a18645d2d6faa68a43963a6cb98560b5a6))

## [0.31.45](https://github.com/cube-js/cube.js/compare/v0.31.44...v0.31.45) (2023-01-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.44](https://github.com/cube-js/cube.js/compare/v0.31.43...v0.31.44) (2023-01-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.43](https://github.com/cube-js/cube.js/compare/v0.31.42...v0.31.43) (2023-01-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.42](https://github.com/cube-js/cube.js/compare/v0.31.41...v0.31.42) (2023-01-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.41](https://github.com/cube-js/cube.js/compare/v0.31.40...v0.31.41) (2023-01-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.40](https://github.com/cube-js/cube.js/compare/v0.31.39...v0.31.40) (2023-01-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.39](https://github.com/cube-js/cube.js/compare/v0.31.38...v0.31.39) (2023-01-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.38](https://github.com/cube-js/cube.js/compare/v0.31.37...v0.31.38) (2023-01-11)

### Bug Fixes

- **athena-driver:** Add catalog config ([#5835](https://github.com/cube-js/cube.js/issues/5835)) Thanks [@tkislan](https://github.com/tkislan) ! ([c33a5c5](https://github.com/cube-js/cube.js/commit/c33a5c596622c5a2b67987da6cfd3f8bef6acebe))
- **athena-driver:** TypeError: table.join is not a function ([#5988](https://github.com/cube-js/cube.js/issues/5988)) ([4e56a04](https://github.com/cube-js/cube.js/commit/4e56a0402dbb13d757e073fb38a547522c0936d1)), closes [#5143](https://github.com/cube-js/cube.js/issues/5143)

## [0.31.37](https://github.com/cube-js/cube.js/compare/v0.31.36...v0.31.37) (2023-01-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.36](https://github.com/cube-js/cube.js/compare/v0.31.35...v0.31.36) (2023-01-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.35](https://github.com/cube-js/cube.js/compare/v0.31.34...v0.31.35) (2023-01-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.34](https://github.com/cube-js/cube.js/compare/v0.31.33...v0.31.34) (2023-01-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.33](https://github.com/cube-js/cube.js/compare/v0.31.32...v0.31.33) (2023-01-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.32](https://github.com/cube-js/cube.js/compare/v0.31.31...v0.31.32) (2022-12-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.31](https://github.com/cube-js/cube.js/compare/v0.31.30...v0.31.31) (2022-12-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.30](https://github.com/cube-js/cube.js/compare/v0.31.29...v0.31.30) (2022-12-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.29](https://github.com/cube-js/cube.js/compare/v0.31.28...v0.31.29) (2022-12-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.28](https://github.com/cube-js/cube.js/compare/v0.31.27...v0.31.28) (2022-12-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.26](https://github.com/cube-js/cube.js/compare/v0.31.25...v0.31.26) (2022-12-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.23](https://github.com/cube-js/cube.js/compare/v0.31.22...v0.31.23) (2022-12-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.21](https://github.com/cube-js/cube.js/compare/v0.31.20...v0.31.21) (2022-12-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.19](https://github.com/cube-js/cube.js/compare/v0.31.18...v0.31.19) (2022-11-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.18](https://github.com/cube-js/cube.js/compare/v0.31.17...v0.31.18) (2022-11-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.16](https://github.com/cube-js/cube.js/compare/v0.31.15...v0.31.16) (2022-11-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.15](https://github.com/cube-js/cube.js/compare/v0.31.14...v0.31.15) (2022-11-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.14](https://github.com/cube-js/cube.js/compare/v0.31.13...v0.31.14) (2022-11-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.13](https://github.com/cube-js/cube.js/compare/v0.31.12...v0.31.13) (2022-11-08)

### Features

- export bucket CVS files escape symbol support ([#5570](https://github.com/cube-js/cube.js/issues/5570)) ([09ceffb](https://github.com/cube-js/cube.js/commit/09ceffbefc75417555f8ff90f6277bd9c419d751))

## [0.31.12](https://github.com/cube-js/cube.js/compare/v0.31.11...v0.31.12) (2022-11-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.11](https://github.com/cube-js/cube.js/compare/v0.31.10...v0.31.11) (2022-11-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.9](https://github.com/cube-js/cube.js/compare/v0.31.8...v0.31.9) (2022-11-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.8](https://github.com/cube-js/cube.js/compare/v0.31.7...v0.31.8) (2022-10-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.7](https://github.com/cube-js/cube.js/compare/v0.31.6...v0.31.7) (2022-10-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.5](https://github.com/cube-js/cube.js/compare/v0.31.4...v0.31.5) (2022-10-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.4](https://github.com/cube-js/cube.js/compare/v0.31.3...v0.31.4) (2022-10-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.3](https://github.com/cube-js/cube.js/compare/v0.31.2...v0.31.3) (2022-10-08)

### Bug Fixes

- drivers imports alignment ([#5448](https://github.com/cube-js/cube.js/issues/5448)) ([ab12426](https://github.com/cube-js/cube.js/commit/ab1242650ba0368b855176b9c6ca2d73073acf0e))

## [0.31.2](https://github.com/cube-js/cube.js/compare/v0.31.1...v0.31.2) (2022-10-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.31.1](https://github.com/cube-js/cube.js/compare/v0.31.0...v0.31.1) (2022-10-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.31.0](https://github.com/cube-js/cube.js/compare/v0.30.75...v0.31.0) (2022-10-03)

### Features

- multiple data source ([#5326](https://github.com/cube-js/cube.js/issues/5326)) ([334af8c](https://github.com/cube-js/cube.js/commit/334af8c56cd02ae551844e9d1e9ab5e107fb1555))

## [0.30.75](https://github.com/cube-js/cube.js/compare/v0.30.74...v0.30.75) (2022-09-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.73](https://github.com/cube-js/cube.js/compare/v0.30.72...v0.30.73) (2022-09-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.72](https://github.com/cube-js/cube.js/compare/v0.30.71...v0.30.72) (2022-09-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.70](https://github.com/cube-js/cube.js/compare/v0.30.69...v0.30.70) (2022-09-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.69](https://github.com/cube-js/cube.js/compare/v0.30.68...v0.30.69) (2022-09-13)

### Features

- **base-driver:** Split BaseDriver to @cubejs-backend/base-driver ([#5283](https://github.com/cube-js/cube.js/issues/5283)) ([ca7f9d2](https://github.com/cube-js/cube.js/commit/ca7f9d280c3518e012683c23b82175ec1f96d2a8))

## [0.30.67](https://github.com/cube-js/cube.js/compare/v0.30.66...v0.30.67) (2022-09-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.63](https://github.com/cube-js/cube.js/compare/v0.30.62...v0.30.63) (2022-09-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.61](https://github.com/cube-js/cube.js/compare/v0.30.60...v0.30.61) (2022-09-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.60](https://github.com/cube-js/cube.js/compare/v0.30.59...v0.30.60) (2022-08-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.57](https://github.com/cube-js/cube.js/compare/v0.30.56...v0.30.57) (2022-08-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.53](https://github.com/cube-js/cube.js/compare/v0.30.52...v0.30.53) (2022-08-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.51](https://github.com/cube-js/cube.js/compare/v0.30.50...v0.30.51) (2022-08-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.50](https://github.com/cube-js/cube.js/compare/v0.30.49...v0.30.50) (2022-08-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.47](https://github.com/cube-js/cube.js/compare/v0.30.46...v0.30.47) (2022-08-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.46](https://github.com/cube-js/cube.js/compare/v0.30.45...v0.30.46) (2022-08-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.45](https://github.com/cube-js/cube.js/compare/v0.30.44...v0.30.45) (2022-08-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.43](https://github.com/cube-js/cube.js/compare/v0.30.42...v0.30.43) (2022-07-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.39](https://github.com/cube-js/cube.js/compare/v0.30.38...v0.30.39) (2022-07-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.34](https://github.com/cube-js/cube.js/compare/v0.30.33...v0.30.34) (2022-07-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.30](https://github.com/cube-js/cube.js/compare/v0.30.29...v0.30.30) (2022-07-05)

### Bug Fixes

- drivers default concurrency values ([4b7296f](https://github.com/cube-js/cube.js/commit/4b7296f266b49e3d38dce1ff82ce4edd703121bc))

### Features

- centralized concurrency setting ([#4735](https://github.com/cube-js/cube.js/issues/4735)) ([1c897a1](https://github.com/cube-js/cube.js/commit/1c897a13c62049e23d26009351622b2a93c0a745))

## [0.30.28](https://github.com/cube-js/cube.js/compare/v0.30.27...v0.30.28) (2022-06-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.27](https://github.com/cube-js/cube.js/compare/v0.30.26...v0.30.27) (2022-06-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.25](https://github.com/cube-js/cube.js/compare/v0.30.24...v0.30.25) (2022-06-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.20](https://github.com/cube-js/cube.js/compare/v0.30.19...v0.30.20) (2022-06-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.8](https://github.com/cube-js/cube.js/compare/v0.30.7...v0.30.8) (2022-05-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.7](https://github.com/cube-js/cube.js/compare/v0.30.6...v0.30.7) (2022-05-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.6](https://github.com/cube-js/cube.js/compare/v0.30.5...v0.30.6) (2022-05-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.5](https://github.com/cube-js/cube.js/compare/v0.30.4...v0.30.5) (2022-05-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.4](https://github.com/cube-js/cube.js/compare/v0.30.3...v0.30.4) (2022-05-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.30.1](https://github.com/cube-js/cube.js/compare/v0.30.0...v0.30.1) (2022-05-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.30.0](https://github.com/cube-js/cube.js/compare/v0.29.57...v0.30.0) (2022-05-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.57](https://github.com/cube-js/cube.js/compare/v0.29.56...v0.29.57) (2022-05-11)

### Bug Fixes

- **drivers:** Fixes error when data result is empty for AthenaDriver ([1e7e203](https://github.com/cube-js/cube.js/commit/1e7e203c63ecccae3fb199afd515850cd834d074))

## [0.29.54](https://github.com/cube-js/cube.js/compare/v0.29.53...v0.29.54) (2022-05-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.53](https://github.com/cube-js/cube.js/compare/v0.29.52...v0.29.53) (2022-04-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.52](https://github.com/cube-js/cube.js/compare/v0.29.51...v0.29.52) (2022-04-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.51](https://github.com/cube-js/cube.js/compare/v0.29.50...v0.29.51) (2022-04-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.49](https://github.com/cube-js/cube.js/compare/v0.29.48...v0.29.49) (2022-04-15)

### Bug Fixes

- **athena:** Support plain bucket for CUBEJS_DB_EXPORT_BUCKET ([#4390](https://github.com/cube-js/cube.js/issues/4390)) ([4b4dd60](https://github.com/cube-js/cube.js/commit/4b4dd60256dcbd36d049fb02078459a7873f1ecd))

## [0.29.48](https://github.com/cube-js/cube.js/compare/v0.29.47...v0.29.48) (2022-04-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.42](https://github.com/cube-js/cube.js/compare/v0.29.41...v0.29.42) (2022-04-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.37](https://github.com/cube-js/cube.js/compare/v0.29.36...v0.29.37) (2022-03-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.35](https://github.com/cube-js/cube.js/compare/v0.29.34...v0.29.35) (2022-03-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.33](https://github.com/cube-js/cube.js/compare/v0.29.32...v0.29.33) (2022-03-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.31](https://github.com/cube-js/cube.js/compare/v0.29.30...v0.29.31) (2022-03-09)

### Bug Fixes

- **athena:** Fixes export bucket location. Fixes column order. ([#4183](https://github.com/cube-js/cube.js/issues/4183)) ([abd40a7](https://github.com/cube-js/cube.js/commit/abd40a79e360cd9a9eceeb56a450102bd782f3d9))

## [0.29.30](https://github.com/cube-js/cube.js/compare/v0.29.29...v0.29.30) (2022-03-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.29](https://github.com/cube-js/cube.js/compare/v0.29.28...v0.29.29) (2022-03-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.28](https://github.com/cube-js/cube.js/compare/v0.29.27...v0.29.28) (2022-02-10)

### Bug Fixes

- **@cubejs-backend/athena-driver:** Batching and export support ([#4039](https://github.com/cube-js/cube.js/issues/4039)) ([108f42a](https://github.com/cube-js/cube.js/commit/108f42afdd58ae0027b1b81730f7ca9e72ab9122))

## [0.29.25](https://github.com/cube-js/cube.js/compare/v0.29.24...v0.29.25) (2022-02-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.24](https://github.com/cube-js/cube.js/compare/v0.29.23...v0.29.24) (2022-02-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.23](https://github.com/cube-js/cube.js/compare/v0.29.22...v0.29.23) (2022-01-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.22](https://github.com/cube-js/cube.js/compare/v0.29.21...v0.29.22) (2022-01-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.21](https://github.com/cube-js/cube.js/compare/v0.29.20...v0.29.21) (2022-01-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.20](https://github.com/cube-js/cube.js/compare/v0.29.19...v0.29.20) (2022-01-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.18](https://github.com/cube-js/cube.js/compare/v0.29.17...v0.29.18) (2022-01-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.15](https://github.com/cube-js/cube.js/compare/v0.29.14...v0.29.15) (2021-12-30)

### Features

- Introduce single unified CUBEJS_DB_QUERY_TIMEOUT env variable to set all various variables that control database query timeouts ([#3864](https://github.com/cube-js/cube.js/issues/3864)) ([33c6292](https://github.com/cube-js/cube.js/commit/33c6292059e65e293a7e3d61e1f1e0c1413eeece))

## [0.29.12](https://github.com/cube-js/cube.js/compare/v0.29.11...v0.29.12) (2021-12-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.7](https://github.com/cube-js/cube.js/compare/v0.29.6...v0.29.7) (2021-12-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.29.6](https://github.com/cube-js/cube.js/compare/v0.29.5...v0.29.6) (2021-12-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.29.0](https://github.com/cube-js/cube.js/compare/v0.28.67...v0.29.0) (2021-12-14)

### Reverts

- Revert "BREAKING CHANGE: 0.29 (#3809)" (#3811) ([db005ed](https://github.com/cube-js/cube.js/commit/db005edc04d48e8251250ab9d0e19f496cf3b52b)), closes [#3809](https://github.com/cube-js/cube.js/issues/3809) [#3811](https://github.com/cube-js/cube.js/issues/3811)

- BREAKING CHANGE: 0.29 (#3809) ([6f1418b](https://github.com/cube-js/cube.js/commit/6f1418b9963774844f341682e594601a56bb0084)), closes [#3809](https://github.com/cube-js/cube.js/issues/3809)

### BREAKING CHANGES

- Drop support for Node.js 10 (12.x is a minimal version)
- Upgrade Node.js to 14 for Docker images
- Drop support for Node.js 15

## [0.28.64](https://github.com/cube-js/cube.js/compare/v0.28.63...v0.28.64) (2021-12-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.63](https://github.com/cube-js/cube.js/compare/v0.28.62...v0.28.63) (2021-12-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.61](https://github.com/cube-js/cube.js/compare/v0.28.60...v0.28.61) (2021-11-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.60](https://github.com/cube-js/cube.js/compare/v0.28.59...v0.28.60) (2021-11-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.59](https://github.com/cube-js/cube.js/compare/v0.28.58...v0.28.59) (2021-11-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.58](https://github.com/cube-js/cube.js/compare/v0.28.57...v0.28.58) (2021-11-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.56](https://github.com/cube-js/cube.js/compare/v0.28.55...v0.28.56) (2021-11-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.55](https://github.com/cube-js/cube.js/compare/v0.28.54...v0.28.55) (2021-11-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.52](https://github.com/cube-js/cube.js/compare/v0.28.51...v0.28.52) (2021-11-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.50](https://github.com/cube-js/cube.js/compare/v0.28.49...v0.28.50) (2021-10-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.47](https://github.com/cube-js/cube.js/compare/v0.28.46...v0.28.47) (2021-10-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.42](https://github.com/cube-js/cube.js/compare/v0.28.41...v0.28.42) (2021-10-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.38](https://github.com/cube-js/cube.js/compare/v0.28.37...v0.28.38) (2021-09-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.37](https://github.com/cube-js/cube.js/compare/v0.28.36...v0.28.37) (2021-09-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.34](https://github.com/cube-js/cube.js/compare/v0.28.33...v0.28.34) (2021-09-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.33](https://github.com/cube-js/cube.js/compare/v0.28.32...v0.28.33) (2021-09-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.32](https://github.com/cube-js/cube.js/compare/v0.28.31...v0.28.32) (2021-09-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.29](https://github.com/cube-js/cube.js/compare/v0.28.28...v0.28.29) (2021-08-31)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.27](https://github.com/cube-js/cube.js/compare/v0.28.26...v0.28.27) (2021-08-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.25](https://github.com/cube-js/cube.js/compare/v0.28.24...v0.28.25) (2021-08-20)

### Features

- **athena-driver:** Allow to configure workGroup ([#3254](https://github.com/cube-js/cube.js/issues/3254)) ([a300038](https://github.com/cube-js/cube.js/commit/a300038921c8fb93f2d255b32afc5c7e8150cf65))

## [0.28.24](https://github.com/cube-js/cube.js/compare/v0.28.23...v0.28.24) (2021-08-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.22](https://github.com/cube-js/cube.js/compare/v0.28.21...v0.28.22) (2021-08-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.19](https://github.com/cube-js/cube.js/compare/v0.28.18...v0.28.19) (2021-08-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.17](https://github.com/cube-js/cube.js/compare/v0.28.16...v0.28.17) (2021-08-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.15](https://github.com/cube-js/cube.js/compare/v0.28.14...v0.28.15) (2021-08-06)

### Bug Fixes

- **athena-driver:** Typings for driver (wrong import) ([fe6d429](https://github.com/cube-js/cube.js/commit/fe6d429c8ddf04702401c424143c113e92da0650))

### Features

- **athena-driver:** Use getWorkGroup instead of SELECT 1 for testConnection ([a99a6e4](https://github.com/cube-js/cube.js/commit/a99a6e4bb5b5dad5558a74683f8618696c1786c0))

## [0.28.14](https://github.com/cube-js/cube.js/compare/v0.28.13...v0.28.14) (2021-08-05)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.13](https://github.com/cube-js/cube.js/compare/v0.28.12...v0.28.13) (2021-08-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.11](https://github.com/cube-js/cube.js/compare/v0.28.10...v0.28.11) (2021-07-31)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.10](https://github.com/cube-js/cube.js/compare/v0.28.9...v0.28.10) (2021-07-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.9](https://github.com/cube-js/cube.js/compare/v0.28.8...v0.28.9) (2021-07-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.8](https://github.com/cube-js/cube.js/compare/v0.28.7...v0.28.8) (2021-07-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.7](https://github.com/cube-js/cube.js/compare/v0.28.6...v0.28.7) (2021-07-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.6](https://github.com/cube-js/cube.js/compare/v0.28.5...v0.28.6) (2021-07-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.4](https://github.com/cube-js/cube.js/compare/v0.28.3...v0.28.4) (2021-07-20)

### Features

- **athena-driver:** Use AWS-SDK v3 (modular) ([f14b7c1](https://github.com/cube-js/cube.js/commit/f14b7c1a12d25fc9e140bfb352a1eb4ca4a11cda))

## [0.28.3](https://github.com/cube-js/cube.js/compare/v0.28.2...v0.28.3) (2021-07-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.2](https://github.com/cube-js/cube.js/compare/v0.28.1...v0.28.2) (2021-07-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.28.1](https://github.com/cube-js/cube.js/compare/v0.28.0...v0.28.1) (2021-07-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.28.0](https://github.com/cube-js/cube.js/compare/v0.27.53...v0.28.0) (2021-07-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.53](https://github.com/cube-js/cube.js/compare/v0.27.52...v0.27.53) (2021-07-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.51](https://github.com/cube-js/cube.js/compare/v0.27.50...v0.27.51) (2021-07-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.49](https://github.com/cube-js/cube.js/compare/v0.27.48...v0.27.49) (2021-07-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.47](https://github.com/cube-js/cube.js/compare/v0.27.46...v0.27.47) (2021-07-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.46](https://github.com/cube-js/cube.js/compare/v0.27.45...v0.27.46) (2021-07-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.45](https://github.com/cube-js/cube.js/compare/v0.27.44...v0.27.45) (2021-06-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.41](https://github.com/cube-js/cube.js/compare/v0.27.40...v0.27.41) (2021-06-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.39](https://github.com/cube-js/cube.js/compare/v0.27.38...v0.27.39) (2021-06-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.38](https://github.com/cube-js/cube.js/compare/v0.27.37...v0.27.38) (2021-06-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.37](https://github.com/cube-js/cube.js/compare/v0.27.36...v0.27.37) (2021-06-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.35](https://github.com/cube-js/cube.js/compare/v0.27.34...v0.27.35) (2021-06-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.34](https://github.com/cube-js/cube.js/compare/v0.27.33...v0.27.34) (2021-06-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.33](https://github.com/cube-js/cube.js/compare/v0.27.32...v0.27.33) (2021-06-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.32](https://github.com/cube-js/cube.js/compare/v0.27.31...v0.27.32) (2021-06-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.31](https://github.com/cube-js/cube.js/compare/v0.27.30...v0.27.31) (2021-06-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.30](https://github.com/cube-js/cube.js/compare/v0.27.29...v0.27.30) (2021-06-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.25](https://github.com/cube-js/cube.js/compare/v0.27.24...v0.27.25) (2021-06-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.22](https://github.com/cube-js/cube.js/compare/v0.27.21...v0.27.22) (2021-05-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.17](https://github.com/cube-js/cube.js/compare/v0.27.16...v0.27.17) (2021-05-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.16](https://github.com/cube-js/cube.js/compare/v0.27.15...v0.27.16) (2021-05-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.15](https://github.com/cube-js/cube.js/compare/v0.27.14...v0.27.15) (2021-05-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.13](https://github.com/cube-js/cube.js/compare/v0.27.12...v0.27.13) (2021-05-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.10](https://github.com/cube-js/cube.js/compare/v0.27.9...v0.27.10) (2021-05-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.5](https://github.com/cube-js/cube.js/compare/v0.27.4...v0.27.5) (2021-05-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.4](https://github.com/cube-js/cube.js/compare/v0.27.3...v0.27.4) (2021-04-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.2](https://github.com/cube-js/cube.js/compare/v0.27.1...v0.27.2) (2021-04-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.27.1](https://github.com/cube-js/cube.js/compare/v0.27.0...v0.27.1) (2021-04-27)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.27.0](https://github.com/cube-js/cube.js/compare/v0.26.104...v0.27.0) (2021-04-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.103](https://github.com/cube-js/cube.js/compare/v0.26.102...v0.26.103) (2021-04-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.101](https://github.com/cube-js/cube.js/compare/v0.26.100...v0.26.101) (2021-04-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.99](https://github.com/cube-js/cube.js/compare/v0.26.98...v0.26.99) (2021-04-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.95](https://github.com/cube-js/cube.js/compare/v0.26.94...v0.26.95) (2021-04-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.90](https://github.com/cube-js/cube.js/compare/v0.26.89...v0.26.90) (2021-04-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.88](https://github.com/cube-js/cube.js/compare/v0.26.87...v0.26.88) (2021-04-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.87](https://github.com/cube-js/cube.js/compare/v0.26.86...v0.26.87) (2021-04-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.81](https://github.com/cube-js/cube.js/compare/v0.26.80...v0.26.81) (2021-04-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.79](https://github.com/cube-js/cube.js/compare/v0.26.78...v0.26.79) (2021-04-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.78](https://github.com/cube-js/cube.js/compare/v0.26.77...v0.26.78) (2021-04-05)

### Bug Fixes

- **athena-driver:** Wrong escape, Use " for column names, ` for table/schema ([62d8fcf](https://github.com/cube-js/cube.js/commit/62d8fcfb145ac04de72086b354bd583279617481))

## [0.26.77](https://github.com/cube-js/cube.js/compare/v0.26.76...v0.26.77) (2021-04-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.76](https://github.com/cube-js/cube.js/compare/v0.26.75...v0.26.76) (2021-04-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.74](https://github.com/cube-js/cube.js/compare/v0.26.73...v0.26.74) (2021-04-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.72](https://github.com/cube-js/cube.js/compare/v0.26.71...v0.26.72) (2021-03-29)

### Bug Fixes

- **athena-driver:** Use correct quoteIdentifier, fix [#2363](https://github.com/cube-js/cube.js/issues/2363) ([968b3b7](https://github.com/cube-js/cube.js/commit/968b3b7363b0d2c6c8385c717f3d1f29300c5caf))

## [0.26.69](https://github.com/cube-js/cube.js/compare/v0.26.68...v0.26.69) (2021-03-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.65](https://github.com/cube-js/cube.js/compare/v0.26.64...v0.26.65) (2021-03-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.54](https://github.com/cube-js/cube.js/compare/v0.26.53...v0.26.54) (2021-03-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.45](https://github.com/cube-js/cube.js/compare/v0.26.44...v0.26.45) (2021-03-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.38](https://github.com/cube-js/cube.js/compare/v0.26.37...v0.26.38) (2021-02-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.35](https://github.com/cube-js/cube.js/compare/v0.26.34...v0.26.35) (2021-02-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.25](https://github.com/cube-js/cube.js/compare/v0.26.24...v0.26.25) (2021-02-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.23](https://github.com/cube-js/cube.js/compare/v0.26.22...v0.26.23) (2021-02-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.22](https://github.com/cube-js/cube.js/compare/v0.26.21...v0.26.22) (2021-02-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.19](https://github.com/cube-js/cube.js/compare/v0.26.18...v0.26.19) (2021-02-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.16](https://github.com/cube-js/cube.js/compare/v0.26.15...v0.26.16) (2021-02-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.15](https://github.com/cube-js/cube.js/compare/v0.26.14...v0.26.15) (2021-02-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.13](https://github.com/cube-js/cube.js/compare/v0.26.12...v0.26.13) (2021-02-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.12](https://github.com/cube-js/cube.js/compare/v0.26.11...v0.26.12) (2021-02-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.11](https://github.com/cube-js/cube.js/compare/v0.26.10...v0.26.11) (2021-02-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.10](https://github.com/cube-js/cube.js/compare/v0.26.9...v0.26.10) (2021-02-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.7](https://github.com/cube-js/cube.js/compare/v0.26.6...v0.26.7) (2021-02-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.6](https://github.com/cube-js/cube.js/compare/v0.26.5...v0.26.6) (2021-02-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.26.2](https://github.com/cube-js/cube.js/compare/v0.26.1...v0.26.2) (2021-02-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.26.0](https://github.com/cube-js/cube.js/compare/v0.25.33...v0.26.0) (2021-02-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.32](https://github.com/cube-js/cube.js/compare/v0.25.31...v0.25.32) (2021-01-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.30](https://github.com/cube-js/cube.js/compare/v0.25.29...v0.25.30) (2021-01-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.29](https://github.com/cube-js/cube.js/compare/v0.25.28...v0.25.29) (2021-01-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.26](https://github.com/cube-js/cube.js/compare/v0.25.25...v0.25.26) (2021-01-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.24](https://github.com/cube-js/cube.js/compare/v0.25.23...v0.25.24) (2021-01-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.23](https://github.com/cube-js/cube.js/compare/v0.25.22...v0.25.23) (2021-01-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.22](https://github.com/cube-js/cube.js/compare/v0.25.21...v0.25.22) (2021-01-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.21](https://github.com/cube-js/cube.js/compare/v0.25.20...v0.25.21) (2021-01-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.20](https://github.com/cube-js/cube.js/compare/v0.25.19...v0.25.20) (2021-01-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.18](https://github.com/cube-js/cube.js/compare/v0.25.17...v0.25.18) (2021-01-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.15](https://github.com/cube-js/cube.js/compare/v0.25.14...v0.25.15) (2021-01-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.13](https://github.com/cube-js/cube.js/compare/v0.25.12...v0.25.13) (2021-01-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.6](https://github.com/cube-js/cube.js/compare/v0.25.5...v0.25.6) (2020-12-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.5](https://github.com/cube-js/cube.js/compare/v0.25.4...v0.25.5) (2020-12-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.4](https://github.com/cube-js/cube.js/compare/v0.25.3...v0.25.4) (2020-12-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.25.2](https://github.com/cube-js/cube.js/compare/v0.25.1...v0.25.2) (2020-12-27)

### Features

- Ability to set timeouts for polling in BigQuery/Athena ([#1675](https://github.com/cube-js/cube.js/issues/1675)) ([dc944b1](https://github.com/cube-js/cube.js/commit/dc944b1aaacc69dd74a9d9d31ceaf43e16d37ccd)), closes [#1672](https://github.com/cube-js/cube.js/issues/1672)

## [0.25.1](https://github.com/cube-js/cube.js/compare/v0.25.0...v0.25.1) (2020-12-24)

### Features

- **athena-driver:** Support readOnly option, add typings ([a519cb8](https://github.com/cube-js/cube.js/commit/a519cb880be2bb2b872c56b092f1273291fbd397))

# [0.25.0](https://github.com/cube-js/cube.js/compare/v0.24.15...v0.25.0) (2020-12-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.24.13](https://github.com/cube-js/cube.js/compare/v0.24.12...v0.24.13) (2020-12-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.24.12](https://github.com/cube-js/cube.js/compare/v0.24.11...v0.24.12) (2020-12-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.24.9](https://github.com/cube-js/cube.js/compare/v0.24.8...v0.24.9) (2020-12-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.24.8](https://github.com/cube-js/cube.js/compare/v0.24.7...v0.24.8) (2020-12-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.24.6](https://github.com/cube-js/cube.js/compare/v0.24.5...v0.24.6) (2020-12-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.24.5](https://github.com/cube-js/cube.js/compare/v0.24.4...v0.24.5) (2020-12-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.24.4](https://github.com/cube-js/cube.js/compare/v0.24.3...v0.24.4) (2020-12-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.24.3](https://github.com/cube-js/cube.js/compare/v0.24.2...v0.24.3) (2020-12-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.24.2](https://github.com/cube-js/cube.js/compare/v0.24.1...v0.24.2) (2020-11-27)

### Features

- **@cubejs-backend/query-orchestrator:** Initial move to TypeScript ([#1462](https://github.com/cube-js/cube.js/issues/1462)) ([101e8dc](https://github.com/cube-js/cube.js/commit/101e8dc90d4b1266c0327adb86cab3e3caa8d4d0))

# [0.24.0](https://github.com/cube-js/cube.js/compare/v0.23.15...v0.24.0) (2020-11-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.23.14](https://github.com/cube-js/cube.js/compare/v0.23.13...v0.23.14) (2020-11-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.23.8](https://github.com/cube-js/cube.js/compare/v0.23.7...v0.23.8) (2020-11-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.23.6](https://github.com/cube-js/cube.js/compare/v0.23.5...v0.23.6) (2020-11-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.23.3](https://github.com/cube-js/cube.js/compare/v0.23.2...v0.23.3) (2020-10-31)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.23.0](https://github.com/cube-js/cube.js/compare/v0.22.4...v0.23.0) (2020-10-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.22.0](https://github.com/cube-js/cube.js/compare/v0.21.2...v0.22.0) (2020-10-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.21.1](https://github.com/cube-js/cube.js/compare/v0.21.0...v0.21.1) (2020-10-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.21.0](https://github.com/cube-js/cube.js/compare/v0.20.15...v0.21.0) (2020-10-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.20.13](https://github.com/cube-js/cube.js/compare/v0.20.12...v0.20.13) (2020-10-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.20.9](https://github.com/cube-js/cube.js/compare/v0.20.8...v0.20.9) (2020-09-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.20.8](https://github.com/cube-js/cube.js/compare/v0.20.7...v0.20.8) (2020-09-16)

### Bug Fixes

- **@cubejs-backend/athena-driver:** Show views in Playground for Athena ([#1090](https://github.com/cube-js/cube.js/issues/1090)) ([f8ce729](https://github.com/cube-js/cube.js/commit/f8ce729))

# [0.20.0](https://github.com/cube-js/cube.js/compare/v0.19.61...v0.20.0) (2020-08-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.61](https://github.com/cube-js/cube.js/compare/v0.19.60...v0.19.61) (2020-08-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.60](https://github.com/cube-js/cube.js/compare/v0.19.59...v0.19.60) (2020-08-08)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.56](https://github.com/cube-js/cube.js/compare/v0.19.55...v0.19.56) (2020-08-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.54](https://github.com/cube-js/cube.js/compare/v0.19.53...v0.19.54) (2020-07-23)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.53](https://github.com/cube-js/cube.js/compare/v0.19.52...v0.19.53) (2020-07-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.52](https://github.com/cube-js/cube.js/compare/v0.19.51...v0.19.52) (2020-07-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.50](https://github.com/cube-js/cube.js/compare/v0.19.49...v0.19.50) (2020-07-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.46](https://github.com/cube-js/cube.js/compare/v0.19.45...v0.19.46) (2020-07-06)

### Features

- Report query usage for Athena and BigQuery ([697b53f](https://github.com/cube-js/cube.js/commit/697b53f))

## [0.19.36](https://github.com/cube-js/cube.js/compare/v0.19.35...v0.19.36) (2020-06-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.17](https://github.com/cube-js/cube.js/compare/v0.19.16...v0.19.17) (2020-05-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.15](https://github.com/cube-js/cube.js/compare/v0.19.14...v0.19.15) (2020-05-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.14](https://github.com/cube-js/cube.js/compare/v0.19.13...v0.19.14) (2020-04-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.9](https://github.com/cube-js/cube.js/compare/v0.19.8...v0.19.9) (2020-04-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.8](https://github.com/cube-js/cube.js/compare/v0.19.7...v0.19.8) (2020-04-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.7](https://github.com/cube-js/cube.js/compare/v0.19.6...v0.19.7) (2020-04-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.6](https://github.com/cube-js/cube.js/compare/v0.19.5...v0.19.6) (2020-04-14)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.19.5](https://github.com/cube-js/cube.js/compare/v0.19.4...v0.19.5) (2020-04-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.19.0](https://github.com/cube-js/cube.js/compare/v0.18.32...v0.19.0) (2020-04-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.18.18](https://github.com/cube-js/cube.js/compare/v0.18.17...v0.18.18) (2020-03-28)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.18.17](https://github.com/cube-js/cube.js/compare/v0.18.16...v0.18.17) (2020-03-24)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.18.13](https://github.com/cube-js/cube.js/compare/v0.18.12...v0.18.13) (2020-03-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.18.12](https://github.com/cube-js/cube.js/compare/v0.18.11...v0.18.12) (2020-03-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.18.11](https://github.com/cube-js/cube.js/compare/v0.18.10...v0.18.11) (2020-03-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.18.7](https://github.com/cube-js/cube.js/compare/v0.18.6...v0.18.7) (2020-03-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.18.6](https://github.com/cube-js/cube.js/compare/v0.18.5...v0.18.6) (2020-03-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.18.5](https://github.com/cube-js/cube.js/compare/v0.18.4...v0.18.5) (2020-03-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.18.4](https://github.com/cube-js/cube.js/compare/v0.18.3...v0.18.4) (2020-03-09)

### Bug Fixes

- Request span for WebSocketTransport is incorrectly set ([54ba5da](https://github.com/cube-js/cube.js/commit/54ba5da))

## [0.18.3](https://github.com/cube-js/cube.js/compare/v0.18.2...v0.18.3) (2020-03-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.18.2](https://github.com/cube-js/cube.js/compare/v0.18.1...v0.18.2) (2020-03-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.18.1](https://github.com/cube-js/cube.js/compare/v0.18.0...v0.18.1) (2020-03-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.18.0](https://github.com/cube-js/cube.js/compare/v0.17.10...v0.18.0) (2020-03-01)

### Bug Fixes

- **athena-driver:** Remove debug output ([f538135](https://github.com/cube-js/cube.js/commit/f538135))

## [0.17.10](https://github.com/cube-js/cube.js/compare/v0.17.9...v0.17.10) (2020-02-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.17.9](https://github.com/cube-js/cube.js/compare/v0.17.8...v0.17.9) (2020-02-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.17.5](https://github.com/cube-js/cube.js/compare/v0.17.4...v0.17.5) (2020-02-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.17.3](https://github.com/cube-js/cube.js/compare/v0.17.2...v0.17.3) (2020-02-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.17.0](https://github.com/cube-js/cube.js/compare/v0.16.0...v0.17.0) (2020-02-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.16.0](https://github.com/cube-js/cube.js/compare/v0.15.4...v0.16.0) (2020-02-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.15.0](https://github.com/cube-js/cube.js/compare/v0.14.3...v0.15.0) (2020-01-18)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.14.0](https://github.com/cube-js/cube.js/compare/v0.13.12...v0.14.0) (2020-01-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.13.12](https://github.com/cube-js/cube.js/compare/v0.13.11...v0.13.12) (2020-01-12)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.13.9](https://github.com/cube-js/cube.js/compare/v0.13.8...v0.13.9) (2020-01-03)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.13.2](https://github.com/cube-js/cube.js/compare/v0.13.1...v0.13.2) (2019-12-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.13.0](https://github.com/cube-js/cube.js/compare/v0.12.3...v0.13.0) (2019-12-10)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.12.2](https://github.com/cube-js/cube.js/compare/v0.12.1...v0.12.2) (2019-12-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.12.1](https://github.com/cube-js/cube.js/compare/v0.12.0...v0.12.1) (2019-11-26)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.12.0](https://github.com/cube-js/cube.js/compare/v0.11.25...v0.12.0) (2019-11-25)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.11.18](https://github.com/cube-js/cube.js/compare/v0.11.17...v0.11.18) (2019-11-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.11.6](https://github.com/statsbotco/cubejs-client/compare/v0.11.5...v0.11.6) (2019-10-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.11.0](https://github.com/statsbotco/cubejs-client/compare/v0.10.62...v0.11.0) (2019-10-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.10.58](https://github.com/statsbotco/cubejs-client/compare/v0.10.57...v0.10.58) (2019-10-04)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.10.35](https://github.com/statsbotco/cubejs-client/compare/v0.10.34...v0.10.35) (2019-09-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.10.33](https://github.com/statsbotco/cubejs-client/compare/v0.10.32...v0.10.33) (2019-09-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.10.32](https://github.com/statsbotco/cubejs-client/compare/v0.10.31...v0.10.32) (2019-09-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.10.31](https://github.com/statsbotco/cubejs-client/compare/v0.10.30...v0.10.31) (2019-08-27)

### Bug Fixes

- **athena-driver:** TypeError: Cannot read property 'map' of undefined ([478c6c6](https://github.com/statsbotco/cubejs-client/commit/478c6c6))

## [0.10.30](https://github.com/statsbotco/cubejs-client/compare/v0.10.29...v0.10.30) (2019-08-26)

### Bug Fixes

- Athena doesn't support `_` in contains filter ([d330be4](https://github.com/statsbotco/cubejs-client/commit/d330be4))
- Athena doesn't support `'` in contains filter ([40a36d5](https://github.com/statsbotco/cubejs-client/commit/40a36d5))

## [0.10.28](https://github.com/statsbotco/cubejs-client/compare/v0.10.27...v0.10.28) (2019-08-19)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.10.24](https://github.com/statsbotco/cubejs-client/compare/v0.10.23...v0.10.24) (2019-08-16)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.10.16](https://github.com/statsbotco/cubejs-client/compare/v0.10.15...v0.10.16) (2019-07-20)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.10.15](https://github.com/statsbotco/cubejs-client/compare/v0.10.14...v0.10.15) (2019-07-13)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.10.12](https://github.com/statsbotco/cubejs-client/compare/v0.10.11...v0.10.12) (2019-07-06)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.10.11](https://github.com/statsbotco/cubejs-client/compare/v0.10.10...v0.10.11) (2019-07-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.10.0](https://github.com/statsbotco/cubejs-client/compare/v0.9.24...v0.10.0) (2019-06-21)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.9.14](https://github.com/statsbotco/cubejs-client/compare/v0.9.13...v0.9.14) (2019-06-07)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.9.4](https://github.com/statsbotco/cubejs-client/compare/v0.9.3...v0.9.4) (2019-05-22)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.9.2](https://github.com/statsbotco/cubejs-client/compare/v0.9.1...v0.9.2) (2019-05-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.9.1](https://github.com/statsbotco/cubejs-client/compare/v0.9.0...v0.9.1) (2019-05-11)

### Bug Fixes

- update BaseDriver dependencies ([a7aef2b](https://github.com/statsbotco/cubejs-client/commit/a7aef2b))

# [0.9.0](https://github.com/statsbotco/cubejs-client/compare/v0.8.7...v0.9.0) (2019-05-11)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.8.4](https://github.com/statsbotco/cubejs-client/compare/v0.8.3...v0.8.4) (2019-05-02)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.8.1](https://github.com/statsbotco/cubejs-client/compare/v0.8.0...v0.8.1) (2019-04-30)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.8.0](https://github.com/statsbotco/cubejs-client/compare/v0.7.10...v0.8.0) (2019-04-29)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.7.0](https://github.com/statsbotco/cubejs-client/compare/v0.6.2...v0.7.0) (2019-04-15)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.6.0](https://github.com/statsbotco/cubejs-client/compare/v0.5.2...v0.6.0) (2019-04-09)

**Note:** Version bump only for package @cubejs-backend/athena-driver

# [0.5.0](https://github.com/statsbotco/cubejs-client/compare/v0.4.6...v0.5.0) (2019-04-01)

**Note:** Version bump only for package @cubejs-backend/athena-driver

## [0.4.4](https://github.com/statsbotco/cubejs-client/compare/v0.4.3...v0.4.4) (2019-03-17)

**Note:** Version bump only for package @cubejs-backend/athena-driver
