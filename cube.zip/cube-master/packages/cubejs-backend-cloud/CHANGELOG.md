# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.5.16](https://github.com/cube-js/cube/compare/v1.5.15...v1.5.16) (2025-12-17)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.15](https://github.com/cube-js/cube/compare/v1.5.14...v1.5.15) (2025-12-15)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.14](https://github.com/cube-js/cube/compare/v1.5.13...v1.5.14) (2025-12-11)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.13](https://github.com/cube-js/cube/compare/v1.5.12...v1.5.13) (2025-12-10)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.12](https://github.com/cube-js/cube/compare/v1.5.11...v1.5.12) (2025-12-04)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.11](https://github.com/cube-js/cube/compare/v1.5.10...v1.5.11) (2025-12-02)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.10](https://github.com/cube-js/cube/compare/v1.5.9...v1.5.10) (2025-11-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.9](https://github.com/cube-js/cube/compare/v1.5.8...v1.5.9) (2025-11-26)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.8](https://github.com/cube-js/cube/compare/v1.5.7...v1.5.8) (2025-11-26)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.7](https://github.com/cube-js/cube/compare/v1.5.6...v1.5.7) (2025-11-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.6](https://github.com/cube-js/cube/compare/v1.5.5...v1.5.6) (2025-11-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.5](https://github.com/cube-js/cube/compare/v1.5.4...v1.5.5) (2025-11-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.4](https://github.com/cube-js/cube/compare/v1.5.3...v1.5.4) (2025-11-18)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.3](https://github.com/cube-js/cube/compare/v1.5.2...v1.5.3) (2025-11-13)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.2](https://github.com/cube-js/cube/compare/v1.5.1...v1.5.2) (2025-11-10)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.5.1](https://github.com/cube-js/cube/compare/v1.5.0...v1.5.1) (2025-11-04)

**Note:** Version bump only for package @cubejs-backend/cloud

# [1.5.0](https://github.com/cube-js/cube/compare/v1.4.0...v1.5.0) (2025-10-29)

**Note:** Version bump only for package @cubejs-backend/cloud

# [1.4.0](https://github.com/cube-js/cube/compare/v1.3.86...v1.4.0) (2025-10-29)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.86](https://github.com/cube-js/cube/compare/v1.3.85...v1.3.86) (2025-10-29)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.85](https://github.com/cube-js/cube/compare/v1.3.84...v1.3.85) (2025-10-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.84](https://github.com/cube-js/cube/compare/v1.3.83...v1.3.84) (2025-10-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.83](https://github.com/cube-js/cube/compare/v1.3.82...v1.3.83) (2025-10-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.82](https://github.com/cube-js/cube/compare/v1.3.81...v1.3.82) (2025-10-21)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.81](https://github.com/cube-js/cube/compare/v1.3.80...v1.3.81) (2025-10-16)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.80](https://github.com/cube-js/cube/compare/v1.3.79...v1.3.80) (2025-10-15)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.79](https://github.com/cube-js/cube/compare/v1.3.78...v1.3.79) (2025-10-14)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.78](https://github.com/cube-js/cube/compare/v1.3.77...v1.3.78) (2025-10-03)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.77](https://github.com/cube-js/cube/compare/v1.3.76...v1.3.77) (2025-10-01)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.76](https://github.com/cube-js/cube/compare/v1.3.75...v1.3.76) (2025-10-01)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.75](https://github.com/cube-js/cube/compare/v1.3.74...v1.3.75) (2025-09-29)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.74](https://github.com/cube-js/cube/compare/v1.3.73...v1.3.74) (2025-09-26)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.73](https://github.com/cube-js/cube/compare/v1.3.72...v1.3.73) (2025-09-25)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.72](https://github.com/cube-js/cube/compare/v1.3.71...v1.3.72) (2025-09-23)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.71](https://github.com/cube-js/cube/compare/v1.3.70...v1.3.71) (2025-09-22)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.70](https://github.com/cube-js/cube/compare/v1.3.69...v1.3.70) (2025-09-19)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.69](https://github.com/cube-js/cube/compare/v1.3.68...v1.3.69) (2025-09-17)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.68](https://github.com/cube-js/cube/compare/v1.3.67...v1.3.68) (2025-09-16)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.67](https://github.com/cube-js/cube/compare/v1.3.66...v1.3.67) (2025-09-09)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.66](https://github.com/cube-js/cube/compare/v1.3.65...v1.3.66) (2025-09-09)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.65](https://github.com/cube-js/cube/compare/v1.3.64...v1.3.65) (2025-09-05)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.64](https://github.com/cube-js/cube/compare/v1.3.63...v1.3.64) (2025-09-03)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.63](https://github.com/cube-js/cube/compare/v1.3.62...v1.3.63) (2025-09-02)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.62](https://github.com/cube-js/cube/compare/v1.3.61...v1.3.62) (2025-08-29)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.61](https://github.com/cube-js/cube/compare/v1.3.60...v1.3.61) (2025-08-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.60](https://github.com/cube-js/cube/compare/v1.3.59...v1.3.60) (2025-08-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.59](https://github.com/cube-js/cube/compare/v1.3.58...v1.3.59) (2025-08-26)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.58](https://github.com/cube-js/cube/compare/v1.3.57...v1.3.58) (2025-08-25)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.57](https://github.com/cube-js/cube/compare/v1.3.56...v1.3.57) (2025-08-22)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.56](https://github.com/cube-js/cube/compare/v1.3.55...v1.3.56) (2025-08-21)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.55](https://github.com/cube-js/cube/compare/v1.3.54...v1.3.55) (2025-08-19)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.54](https://github.com/cube-js/cube/compare/v1.3.53...v1.3.54) (2025-08-15)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.53](https://github.com/cube-js/cube/compare/v1.3.52...v1.3.53) (2025-08-15)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.52](https://github.com/cube-js/cube/compare/v1.3.51...v1.3.52) (2025-08-14)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.51](https://github.com/cube-js/cube/compare/v1.3.50...v1.3.51) (2025-08-14)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.50](https://github.com/cube-js/cube/compare/v1.3.49...v1.3.50) (2025-08-13)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.49](https://github.com/cube-js/cube/compare/v1.3.48...v1.3.49) (2025-08-12)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.48](https://github.com/cube-js/cube/compare/v1.3.47...v1.3.48) (2025-08-09)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.47](https://github.com/cube-js/cube/compare/v1.3.46...v1.3.47) (2025-08-04)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.46](https://github.com/cube-js/cube/compare/v1.3.45...v1.3.46) (2025-07-31)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.45](https://github.com/cube-js/cube/compare/v1.3.44...v1.3.45) (2025-07-29)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.44](https://github.com/cube-js/cube/compare/v1.3.43...v1.3.44) (2025-07-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.43](https://github.com/cube-js/cube/compare/v1.3.42...v1.3.43) (2025-07-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.42](https://github.com/cube-js/cube/compare/v1.3.41...v1.3.42) (2025-07-23)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.41](https://github.com/cube-js/cube/compare/v1.3.40...v1.3.41) (2025-07-22)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.40](https://github.com/cube-js/cube/compare/v1.3.39...v1.3.40) (2025-07-20)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.39](https://github.com/cube-js/cube/compare/v1.3.38...v1.3.39) (2025-07-17)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.38](https://github.com/cube-js/cube/compare/v1.3.37...v1.3.38) (2025-07-16)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.37](https://github.com/cube-js/cube/compare/v1.3.36...v1.3.37) (2025-07-14)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.36](https://github.com/cube-js/cube/compare/v1.3.35...v1.3.36) (2025-07-10)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.35](https://github.com/cube-js/cube/compare/v1.3.34...v1.3.35) (2025-07-09)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.34](https://github.com/cube-js/cube/compare/v1.3.33...v1.3.34) (2025-07-04)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.33](https://github.com/cube-js/cube/compare/v1.3.32...v1.3.33) (2025-07-03)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.32](https://github.com/cube-js/cube/compare/v1.3.31...v1.3.32) (2025-07-03)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.31](https://github.com/cube-js/cube/compare/v1.3.30...v1.3.31) (2025-07-02)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.30](https://github.com/cube-js/cube/compare/v1.3.29...v1.3.30) (2025-07-01)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.29](https://github.com/cube-js/cube/compare/v1.3.28...v1.3.29) (2025-07-01)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.28](https://github.com/cube-js/cube/compare/v1.3.27...v1.3.28) (2025-06-30)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.27](https://github.com/cube-js/cube/compare/v1.3.26...v1.3.27) (2025-06-30)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.26](https://github.com/cube-js/cube/compare/v1.3.25...v1.3.26) (2025-06-25)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.25](https://github.com/cube-js/cube/compare/v1.3.24...v1.3.25) (2025-06-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.24](https://github.com/cube-js/cube/compare/v1.3.23...v1.3.24) (2025-06-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.23](https://github.com/cube-js/cube/compare/v1.3.22...v1.3.23) (2025-06-19)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.22](https://github.com/cube-js/cube/compare/v1.3.21...v1.3.22) (2025-06-18)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.21](https://github.com/cube-js/cube/compare/v1.3.20...v1.3.21) (2025-06-10)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.20](https://github.com/cube-js/cube/compare/v1.3.19...v1.3.20) (2025-06-06)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.19](https://github.com/cube-js/cube/compare/v1.3.18...v1.3.19) (2025-06-02)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.18](https://github.com/cube-js/cube/compare/v1.3.17...v1.3.18) (2025-05-27)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.17](https://github.com/cube-js/cube/compare/v1.3.16...v1.3.17) (2025-05-22)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.16](https://github.com/cube-js/cube/compare/v1.3.15...v1.3.16) (2025-05-19)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.15](https://github.com/cube-js/cube/compare/v1.3.14...v1.3.15) (2025-05-15)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.14](https://github.com/cube-js/cube/compare/v1.3.13...v1.3.14) (2025-05-13)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.13](https://github.com/cube-js/cube/compare/v1.3.12...v1.3.13) (2025-05-12)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.12](https://github.com/cube-js/cube/compare/v1.3.11...v1.3.12) (2025-05-08)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.11](https://github.com/cube-js/cube/compare/v1.3.10...v1.3.11) (2025-05-05)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.10](https://github.com/cube-js/cube/compare/v1.3.9...v1.3.10) (2025-05-01)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.9](https://github.com/cube-js/cube/compare/v1.3.8...v1.3.9) (2025-04-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.8](https://github.com/cube-js/cube/compare/v1.3.7...v1.3.8) (2025-04-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.7](https://github.com/cube-js/cube/compare/v1.3.6...v1.3.7) (2025-04-23)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.6](https://github.com/cube-js/cube/compare/v1.3.5...v1.3.6) (2025-04-22)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.5](/compare/v1.3.4...v1.3.5) (2025-04-17)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.4](https://github.com/cube-js/cube/compare/v1.3.3...v1.3.4) (2025-04-17)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.3](https://github.com/cube-js/cube/compare/v1.3.2...v1.3.3) (2025-04-16)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.2](https://github.com/cube-js/cube/compare/v1.3.1...v1.3.2) (2025-04-16)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.3.1](https://github.com/cube-js/cube/compare/v1.3.0...v1.3.1) (2025-04-14)

**Note:** Version bump only for package @cubejs-backend/cloud

# [1.3.0](https://github.com/cube-js/cube/compare/v1.2.33...v1.3.0) (2025-04-11)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.33](https://github.com/cube-js/cube/compare/v1.2.32...v1.2.33) (2025-04-10)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.32](/compare/v1.2.31...v1.2.32) (2025-04-08)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.31](https://github.com/cube-js/cube/compare/v1.2.30...v1.2.31) (2025-04-08)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.30](/compare/v1.2.29...v1.2.30) (2025-04-04)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.29](https://github.com/cube-js/cube/compare/v1.2.28...v1.2.29) (2025-04-02)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.28](https://github.com/cube-js/cube/compare/v1.2.27...v1.2.28) (2025-04-01)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.27](https://github.com/cube-js/cube/compare/v1.2.26...v1.2.27) (2025-03-25)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.26](https://github.com/cube-js/cube/compare/v1.2.25...v1.2.26) (2025-03-21)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.25](https://github.com/cube-js/cube/compare/v1.2.24...v1.2.25) (2025-03-20)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.24](/compare/v1.2.23...v1.2.24) (2025-03-18)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.23](https://github.com/cube-js/cube/compare/v1.2.22...v1.2.23) (2025-03-17)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.22](https://github.com/cube-js/cube/compare/v1.2.21...v1.2.22) (2025-03-14)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.21](https://github.com/cube-js/cube/compare/v1.2.20...v1.2.21) (2025-03-11)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.20](/compare/v1.2.19...v1.2.20) (2025-03-10)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.19](https://github.com/cube-js/cube/compare/v1.2.18...v1.2.19) (2025-03-08)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.18](https://github.com/cube-js/cube/compare/v1.2.17...v1.2.18) (2025-03-06)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.17](/compare/v1.2.16...v1.2.17) (2025-03-05)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.16](https://github.com/cube-js/cube/compare/v1.2.15...v1.2.16) (2025-03-04)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.15](https://github.com/cube-js/cube/compare/v1.2.14...v1.2.15) (2025-03-03)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.14](https://github.com/cube-js/cube/compare/v1.2.13...v1.2.14) (2025-02-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.13](https://github.com/cube-js/cube/compare/v1.2.12...v1.2.13) (2025-02-26)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.12](https://github.com/cube-js/cube/compare/v1.2.11...v1.2.12) (2025-02-26)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.11](https://github.com/cube-js/cube/compare/v1.2.10...v1.2.11) (2025-02-25)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.10](https://github.com/cube-js/cube/compare/v1.2.9...v1.2.10) (2025-02-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.9](https://github.com/cube-js/cube/compare/v1.2.8...v1.2.9) (2025-02-21)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.8](https://github.com/cube-js/cube/compare/v1.2.7...v1.2.8) (2025-02-21)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.7](https://github.com/cube-js/cube/compare/v1.2.6...v1.2.7) (2025-02-20)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.6](https://github.com/cube-js/cube/compare/v1.2.5...v1.2.6) (2025-02-18)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.5](https://github.com/cube-js/cube/compare/v1.2.4...v1.2.5) (2025-02-13)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.4](/compare/v1.2.3...v1.2.4) (2025-02-11)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.3](https://github.com/cube-js/cube/compare/v1.2.2...v1.2.3) (2025-02-06)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.2](https://github.com/cube-js/cube/compare/v1.2.1...v1.2.2) (2025-02-06)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.2.1](https://github.com/cube-js/cube/compare/v1.2.0...v1.2.1) (2025-02-06)

**Note:** Version bump only for package @cubejs-backend/cloud

# [1.2.0](https://github.com/cube-js/cube/compare/v1.1.18...v1.2.0) (2025-02-05)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.1.17](https://github.com/cube-js/cube/compare/v1.1.16...v1.1.17) (2025-01-27)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.1.16](https://github.com/cube-js/cube/compare/v1.1.15...v1.1.16) (2025-01-22)

### Features

- **cli:** Deploy, added --replace-env flag ([#9095](https://github.com/cube-js/cube/issues/9095)) ([80591ea](https://github.com/cube-js/cube/commit/80591ea454f9ca4183967e344c01c616577ab294))

## [1.1.13](https://github.com/cube-js/cube/compare/v1.1.12...v1.1.13) (2025-01-09)

### Bug Fixes

- **cubejs-cli:** Fix content type and body after switching from request to node-fetch ([#9088](https://github.com/cube-js/cube/issues/9088)) ([bf332ef](https://github.com/cube-js/cube/commit/bf332ef6761e8354115cc485d7d762abc9268181))

## [1.1.12](https://github.com/cube-js/cube/compare/v1.1.11...v1.1.12) (2025-01-09)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.1.10](https://github.com/cube-js/cube/compare/v1.1.9...v1.1.10) (2024-12-16)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.1.8](https://github.com/cube-js/cube/compare/v1.1.7...v1.1.8) (2024-12-05)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.1.7](https://github.com/cube-js/cube/compare/v1.1.6...v1.1.7) (2024-11-20)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.1.4](https://github.com/cube-js/cube/compare/v1.1.3...v1.1.4) (2024-11-12)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.1.3](https://github.com/cube-js/cube/compare/v1.1.2...v1.1.3) (2024-11-08)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.1.2](https://github.com/cube-js/cube/compare/v1.1.1...v1.1.2) (2024-11-01)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.0.3](https://github.com/cube-js/cube/compare/v1.0.2...v1.0.3) (2024-10-22)

**Note:** Version bump only for package @cubejs-backend/cloud

## [1.0.2](https://github.com/cube-js/cube/compare/v1.0.1...v1.0.2) (2024-10-21)

**Note:** Version bump only for package @cubejs-backend/cloud

# [1.0.0](https://github.com/cube-js/cube/compare/v0.36.11...v1.0.0) (2024-10-15)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.36.11](https://github.com/cube-js/cube/compare/v0.36.10...v0.36.11) (2024-10-14)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.36.8](https://github.com/cube-js/cube/compare/v0.36.7...v0.36.8) (2024-10-11)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.36.5](https://github.com/cube-js/cube/compare/v0.36.4...v0.36.5) (2024-10-02)

**Note:** Version bump only for package @cubejs-backend/cloud

# [0.36.0](https://github.com/cube-js/cube/compare/v0.35.81...v0.36.0) (2024-09-13)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.35.81](https://github.com/cube-js/cube/compare/v0.35.80...v0.35.81) (2024-09-12)

### Bug Fixes

- Updated jsonwebtoken in all packages ([#8282](https://github.com/cube-js/cube/issues/8282)) Thanks [@jlloyd-widen](https://github.com/jlloyd-widen) ! ([ca7c292](https://github.com/cube-js/cube/commit/ca7c292e0122be50ac7adc9b9d4910623d19f840))

## [0.35.67](https://github.com/cube-js/cube/compare/v0.35.66...v0.35.67) (2024-08-07)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.35.63](https://github.com/cube-js/cube/compare/v0.35.62...v0.35.63) (2024-07-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.35.62](https://github.com/cube-js/cube/compare/v0.35.61...v0.35.62) (2024-07-22)

### Features

- **native:** Initial support for native api-gateway ([#8472](https://github.com/cube-js/cube/issues/8472)) ([d917d6f](https://github.com/cube-js/cube/commit/d917d6fd422090cc78fc30125731d147a091de6c))

## [0.35.43](https://github.com/cube-js/cube/compare/v0.35.42...v0.35.43) (2024-05-31)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.35.33](https://github.com/cube-js/cube.js/compare/v0.35.32...v0.35.33) (2024-05-15)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.35.2](https://github.com/cube-js/cube/compare/v0.35.1...v0.35.2) (2024-03-22)

**Note:** Version bump only for package @cubejs-backend/cloud

# [0.35.0](https://github.com/cube-js/cube/compare/v0.34.62...v0.35.0) (2024-03-14)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.34.60](https://github.com/cube-js/cube.js/compare/v0.34.59...v0.34.60) (2024-03-02)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.34.58](https://github.com/cube-js/cube.js/compare/v0.34.57...v0.34.58) (2024-02-27)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.34.57](https://github.com/cube-js/cube.js/compare/v0.34.56...v0.34.57) (2024-02-26)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.34.55](https://github.com/cube-js/cube.js/compare/v0.34.54...v0.34.55) (2024-02-15)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.34.54](https://github.com/cube-js/cube.js/compare/v0.34.53...v0.34.54) (2024-02-13)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.34.47](https://github.com/cube-js/cube.js/compare/v0.34.46...v0.34.47) (2024-01-23)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.34.41](https://github.com/cube-js/cube.js/compare/v0.34.40...v0.34.41) (2024-01-02)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.34.33](https://github.com/cube-js/cube/compare/v0.34.32...v0.34.33) (2023-12-11)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.34.32](https://github.com/cube-js/cube.js/compare/v0.34.31...v0.34.32) (2023-12-07)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.34.25](https://github.com/cube-js/cube/compare/v0.34.24...v0.34.25) (2023-11-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.34.20](https://github.com/cube-js/cube/compare/v0.34.19...v0.34.20) (2023-11-14)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.34.14](https://github.com/cube-js/cube.js/compare/v0.34.13...v0.34.14) (2023-11-05)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.34.1](https://github.com/cube-js/cube.js/compare/v0.34.0...v0.34.1) (2023-10-09)

**Note:** Version bump only for package @cubejs-backend/cloud

# [0.34.0](https://github.com/cube-js/cube.js/compare/v0.33.65...v0.34.0) (2023-10-03)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.57](https://github.com/cube-js/cube/compare/v0.33.56...v0.33.57) (2023-09-15)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.43](https://github.com/cube-js/cube/compare/v0.33.42...v0.33.43) (2023-08-04)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.41](https://github.com/cube-js/cube/compare/v0.33.40...v0.33.41) (2023-07-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.39](https://github.com/cube-js/cube/compare/v0.33.38...v0.33.39) (2023-07-25)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.34](https://github.com/cube-js/cube/compare/v0.33.33...v0.33.34) (2023-07-12)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.29](https://github.com/cube-js/cube/compare/v0.33.28...v0.33.29) (2023-06-20)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.28](https://github.com/cube-js/cube/compare/v0.33.27...v0.33.28) (2023-06-19)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.26](https://github.com/cube-js/cube/compare/v0.33.25...v0.33.26) (2023-06-14)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.24](https://github.com/cube-js/cube/compare/v0.33.23...v0.33.24) (2023-06-05)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.21](https://github.com/cube-js/cube/compare/v0.33.20...v0.33.21) (2023-05-31)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.20](https://github.com/cube-js/cube/compare/v0.33.19...v0.33.20) (2023-05-31)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.19](https://github.com/cube-js/cube/compare/v0.33.18...v0.33.19) (2023-05-30)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.18](https://github.com/cube-js/cube/compare/v0.33.17...v0.33.18) (2023-05-29)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.33.11](https://github.com/cube-js/cube/compare/v0.33.10...v0.33.11) (2023-05-22)

**Note:** Version bump only for package @cubejs-backend/cloud

# [0.33.0](https://github.com/cube-js/cube.js/compare/v0.32.31...v0.33.0) (2023-05-02)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.32.30](https://github.com/cube-js/cube.js/compare/v0.32.29...v0.32.30) (2023-04-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.32.28](https://github.com/cube-js/cube/compare/v0.32.27...v0.32.28) (2023-04-19)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.32.25](https://github.com/cube-js/cube/compare/v0.32.24...v0.32.25) (2023-04-12)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.32.23](https://github.com/cube-js/cube/compare/v0.32.22...v0.32.23) (2023-04-10)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.32.22](https://github.com/cube-js/cube/compare/v0.32.21...v0.32.22) (2023-04-10)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.32.17](https://github.com/cube-js/cube/compare/v0.32.16...v0.32.17) (2023-03-29)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.32.16](https://github.com/cube-js/cube.js/compare/v0.32.15...v0.32.16) (2023-03-27)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.32.15](https://github.com/cube-js/cube.js/compare/v0.32.14...v0.32.15) (2023-03-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.32.12](https://github.com/cube-js/cube.js/compare/v0.32.11...v0.32.12) (2023-03-22)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.32.2](https://github.com/cube-js/cube.js/compare/v0.32.1...v0.32.2) (2023-03-07)

**Note:** Version bump only for package @cubejs-backend/cloud

# [0.32.0](https://github.com/cube-js/cube.js/compare/v0.31.69...v0.32.0) (2023-03-02)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.67](https://github.com/cube-js/cube.js/compare/v0.31.66...v0.31.67) (2023-02-27)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.66](https://github.com/cube-js/cube.js/compare/v0.31.65...v0.31.66) (2023-02-27)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.65](https://github.com/cube-js/cube.js/compare/v0.31.64...v0.31.65) (2023-02-23)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.62](https://github.com/cube-js/cube.js/compare/v0.31.61...v0.31.62) (2023-02-13)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.60](https://github.com/cube-js/cube.js/compare/v0.31.59...v0.31.60) (2023-02-10)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.57](https://github.com/cube-js/cube.js/compare/v0.31.56...v0.31.57) (2023-02-02)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.55](https://github.com/cube-js/cube.js/compare/v0.31.54...v0.31.55) (2023-01-26)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.48](https://github.com/cube-js/cube.js/compare/v0.31.47...v0.31.48) (2023-01-20)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.42](https://github.com/cube-js/cube.js/compare/v0.31.41...v0.31.42) (2023-01-15)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.41](https://github.com/cube-js/cube.js/compare/v0.31.40...v0.31.41) (2023-01-13)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.40](https://github.com/cube-js/cube.js/compare/v0.31.39...v0.31.40) (2023-01-12)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.38](https://github.com/cube-js/cube.js/compare/v0.31.37...v0.31.38) (2023-01-11)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.33](https://github.com/cube-js/cube.js/compare/v0.31.32...v0.31.33) (2023-01-03)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.32](https://github.com/cube-js/cube.js/compare/v0.31.31...v0.31.32) (2022-12-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.31](https://github.com/cube-js/cube.js/compare/v0.31.30...v0.31.31) (2022-12-23)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.30](https://github.com/cube-js/cube.js/compare/v0.31.29...v0.31.30) (2022-12-22)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.29](https://github.com/cube-js/cube.js/compare/v0.31.28...v0.31.29) (2022-12-18)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.26](https://github.com/cube-js/cube.js/compare/v0.31.25...v0.31.26) (2022-12-13)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.23](https://github.com/cube-js/cube.js/compare/v0.31.22...v0.31.23) (2022-12-09)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.19](https://github.com/cube-js/cube.js/compare/v0.31.18...v0.31.19) (2022-11-29)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.15](https://github.com/cube-js/cube.js/compare/v0.31.14...v0.31.15) (2022-11-17)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.31.13](https://github.com/cube-js/cube.js/compare/v0.31.12...v0.31.13) (2022-11-08)

**Note:** Version bump only for package @cubejs-backend/cloud

# [0.31.0](https://github.com/cube-js/cube.js/compare/v0.30.75...v0.31.0) (2022-10-03)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.69](https://github.com/cube-js/cube.js/compare/v0.30.68...v0.30.69) (2022-09-13)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.57](https://github.com/cube-js/cube.js/compare/v0.30.56...v0.30.57) (2022-08-25)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.53](https://github.com/cube-js/cube.js/compare/v0.30.52...v0.30.53) (2022-08-18)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.50](https://github.com/cube-js/cube.js/compare/v0.30.49...v0.30.50) (2022-08-16)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.47](https://github.com/cube-js/cube.js/compare/v0.30.46...v0.30.47) (2022-08-12)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.46](https://github.com/cube-js/cube.js/compare/v0.30.45...v0.30.46) (2022-08-10)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.45](https://github.com/cube-js/cube.js/compare/v0.30.44...v0.30.45) (2022-08-05)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.43](https://github.com/cube-js/cube.js/compare/v0.30.42...v0.30.43) (2022-07-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.34](https://github.com/cube-js/cube.js/compare/v0.30.33...v0.30.34) (2022-07-12)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.30](https://github.com/cube-js/cube.js/compare/v0.30.29...v0.30.30) (2022-07-05)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.25](https://github.com/cube-js/cube.js/compare/v0.30.24...v0.30.25) (2022-06-16)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.20](https://github.com/cube-js/cube.js/compare/v0.30.19...v0.30.20) (2022-06-11)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.7](https://github.com/cube-js/cube.js/compare/v0.30.6...v0.30.7) (2022-05-26)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.6](https://github.com/cube-js/cube.js/compare/v0.30.5...v0.30.6) (2022-05-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.30.1](https://github.com/cube-js/cube.js/compare/v0.30.0...v0.30.1) (2022-05-14)

**Note:** Version bump only for package @cubejs-backend/cloud

# [0.30.0](https://github.com/cube-js/cube.js/compare/v0.29.57...v0.30.0) (2022-05-11)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.29.51](https://github.com/cube-js/cube.js/compare/v0.29.50...v0.29.51) (2022-04-22)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.29.48](https://github.com/cube-js/cube.js/compare/v0.29.47...v0.29.48) (2022-04-14)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.29.37](https://github.com/cube-js/cube.js/compare/v0.29.36...v0.29.37) (2022-03-29)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.29.33](https://github.com/cube-js/cube.js/compare/v0.29.32...v0.29.33) (2022-03-17)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.29.29](https://github.com/cube-js/cube.js/compare/v0.29.28...v0.29.29) (2022-03-03)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.29.28](https://github.com/cube-js/cube.js/compare/v0.29.27...v0.29.28) (2022-02-10)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.29.23](https://github.com/cube-js/cube.js/compare/v0.29.22...v0.29.23) (2022-01-26)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.29.21](https://github.com/cube-js/cube.js/compare/v0.29.20...v0.29.21) (2022-01-17)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.29.20](https://github.com/cube-js/cube.js/compare/v0.29.19...v0.29.20) (2022-01-10)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.29.18](https://github.com/cube-js/cube.js/compare/v0.29.17...v0.29.18) (2022-01-09)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.29.15](https://github.com/cube-js/cube.js/compare/v0.29.14...v0.29.15) (2021-12-30)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.29.12](https://github.com/cube-js/cube.js/compare/v0.29.11...v0.29.12) (2021-12-29)

**Note:** Version bump only for package @cubejs-backend/cloud

# [0.29.0](https://github.com/cube-js/cube.js/compare/v0.28.67...v0.29.0) (2021-12-14)

### Reverts

- Revert "BREAKING CHANGE: 0.29 (#3809)" (#3811) ([db005ed](https://github.com/cube-js/cube.js/commit/db005edc04d48e8251250ab9d0e19f496cf3b52b)), closes [#3809](https://github.com/cube-js/cube.js/issues/3809) [#3811](https://github.com/cube-js/cube.js/issues/3811)

- BREAKING CHANGE: 0.29 (#3809) ([6f1418b](https://github.com/cube-js/cube.js/commit/6f1418b9963774844f341682e594601a56bb0084)), closes [#3809](https://github.com/cube-js/cube.js/issues/3809)

### BREAKING CHANGES

- Drop support for Node.js 10 (12.x is a minimal version)
- Upgrade Node.js to 14 for Docker images
- Drop support for Node.js 15

## [0.28.55](https://github.com/cube-js/cube.js/compare/v0.28.54...v0.28.55) (2021-11-12)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.52](https://github.com/cube-js/cube.js/compare/v0.28.51...v0.28.52) (2021-11-03)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.50](https://github.com/cube-js/cube.js/compare/v0.28.49...v0.28.50) (2021-10-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.42](https://github.com/cube-js/cube.js/compare/v0.28.41...v0.28.42) (2021-10-15)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.29](https://github.com/cube-js/cube.js/compare/v0.28.28...v0.28.29) (2021-08-31)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.24](https://github.com/cube-js/cube.js/compare/v0.28.23...v0.28.24) (2021-08-19)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.22](https://github.com/cube-js/cube.js/compare/v0.28.21...v0.28.22) (2021-08-17)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.19](https://github.com/cube-js/cube.js/compare/v0.28.18...v0.28.19) (2021-08-13)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.17](https://github.com/cube-js/cube.js/compare/v0.28.16...v0.28.17) (2021-08-11)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.14](https://github.com/cube-js/cube.js/compare/v0.28.13...v0.28.14) (2021-08-05)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.13](https://github.com/cube-js/cube.js/compare/v0.28.12...v0.28.13) (2021-08-04)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.10](https://github.com/cube-js/cube.js/compare/v0.28.9...v0.28.10) (2021-07-30)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.9](https://github.com/cube-js/cube.js/compare/v0.28.8...v0.28.9) (2021-07-29)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.6](https://github.com/cube-js/cube.js/compare/v0.28.5...v0.28.6) (2021-07-22)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.28.2](https://github.com/cube-js/cube.js/compare/v0.28.1...v0.28.2) (2021-07-20)

**Note:** Version bump only for package @cubejs-backend/cloud

# [0.28.0](https://github.com/cube-js/cube.js/compare/v0.27.53...v0.28.0) (2021-07-17)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.47](https://github.com/cube-js/cube.js/compare/v0.27.46...v0.27.47) (2021-07-06)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.46](https://github.com/cube-js/cube.js/compare/v0.27.45...v0.27.46) (2021-07-01)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.45](https://github.com/cube-js/cube.js/compare/v0.27.44...v0.27.45) (2021-06-30)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.37](https://github.com/cube-js/cube.js/compare/v0.27.36...v0.27.37) (2021-06-21)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.35](https://github.com/cube-js/cube.js/compare/v0.27.34...v0.27.35) (2021-06-18)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.33](https://github.com/cube-js/cube.js/compare/v0.27.32...v0.27.33) (2021-06-15)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.31](https://github.com/cube-js/cube.js/compare/v0.27.30...v0.27.31) (2021-06-11)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.30](https://github.com/cube-js/cube.js/compare/v0.27.29...v0.27.30) (2021-06-04)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.22](https://github.com/cube-js/cube.js/compare/v0.27.21...v0.27.22) (2021-05-27)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.17](https://github.com/cube-js/cube.js/compare/v0.27.16...v0.27.17) (2021-05-22)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.15](https://github.com/cube-js/cube.js/compare/v0.27.14...v0.27.15) (2021-05-18)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.14](https://github.com/cube-js/cube.js/compare/v0.27.13...v0.27.14) (2021-05-13)

### Bug Fixes

- **schema-compiler:** Time-series query with minute/second granularity ([c4a6044](https://github.com/cube-js/cube.js/commit/c4a6044702df39629044802b0b5d9e1636cc99d0))

## [0.27.13](https://github.com/cube-js/cube.js/compare/v0.27.12...v0.27.13) (2021-05-13)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.5](https://github.com/cube-js/cube.js/compare/v0.27.4...v0.27.5) (2021-05-03)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.4](https://github.com/cube-js/cube.js/compare/v0.27.3...v0.27.4) (2021-04-29)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.3](https://github.com/cube-js/cube.js/compare/v0.27.2...v0.27.3) (2021-04-29)

### Bug Fixes

- **@cubejs-backend/cloud:** Missed dependency ([#2626](https://github.com/cube-js/cube.js/issues/2626)) ([0d396bf](https://github.com/cube-js/cube.js/commit/0d396bf7bd41c5d9acb8d84ae62bdd4ee33fc2a3))

## [0.27.2](https://github.com/cube-js/cube.js/compare/v0.27.1...v0.27.2) (2021-04-28)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.27.1](https://github.com/cube-js/cube.js/compare/v0.27.0...v0.27.1) (2021-04-27)

**Note:** Version bump only for package @cubejs-backend/cloud

# [0.27.0](https://github.com/cube-js/cube.js/compare/v0.26.104...v0.27.0) (2021-04-26)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.26.103](https://github.com/cube-js/cube.js/compare/v0.26.102...v0.26.103) (2021-04-24)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.26.95](https://github.com/cube-js/cube.js/compare/v0.26.94...v0.26.95) (2021-04-13)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.26.87](https://github.com/cube-js/cube.js/compare/v0.26.86...v0.26.87) (2021-04-10)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.26.84](https://github.com/cube-js/cube.js/compare/v0.26.83...v0.26.84) (2021-04-09)

### Bug Fixes

- **@cubejs-client/playground:** make live preview optional for PlaygroundQueryBuilder ([#2513](https://github.com/cube-js/cube.js/issues/2513)) ([db7a7f5](https://github.com/cube-js/cube.js/commit/db7a7f5fe9783a0c4834d9ace9ffbe710bd266b0))

## [0.26.81](https://github.com/cube-js/cube.js/compare/v0.26.80...v0.26.81) (2021-04-07)

### Features

- Dev mode and live preview ([#2440](https://github.com/cube-js/cube.js/issues/2440)) ([1a7cde8](https://github.com/cube-js/cube.js/commit/1a7cde816ee231ea00d1a952f5000dcc5a8c0ca4))

## [0.26.79](https://github.com/cube-js/cube.js/compare/v0.26.78...v0.26.79) (2021-04-06)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.26.78](https://github.com/cube-js/cube.js/compare/v0.26.77...v0.26.78) (2021-04-05)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.26.74](https://github.com/cube-js/cube.js/compare/v0.26.73...v0.26.74) (2021-04-01)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.26.72](https://github.com/cube-js/cube.js/compare/v0.26.71...v0.26.72) (2021-03-29)

### Bug Fixes

- Persist live token ([#2451](https://github.com/cube-js/cube.js/issues/2451)) ([2f52cac](https://github.com/cube-js/cube.js/commit/2f52cac61b073a7aa20a9ddc2916edff52e1ff08))

## [0.26.69](https://github.com/cube-js/cube.js/compare/v0.26.68...v0.26.69) (2021-03-25)

**Note:** Version bump only for package @cubejs-backend/cloud

## [0.26.68](https://github.com/cube-js/cube.js/compare/v0.26.67...v0.26.68) (2021-03-25)

### Features

- Live preview watcher, refactor cube cloud package ([#2418](https://github.com/cube-js/cube.js/issues/2418)) ([a311843](https://github.com/cube-js/cube.js/commit/a3118439afa5b04d658f79a94d9021f4c7f09472))

## [0.26.65](https://github.com/cube-js/cube.js/compare/v0.26.64...v0.26.65) (2021-03-24)

**Note:** Version bump only for package @cubejs-backend/cloud
