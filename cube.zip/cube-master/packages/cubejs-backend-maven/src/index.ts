export { getDependenciesFromPackage, resolveDependencies } from './maven';
