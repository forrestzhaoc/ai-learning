# Separate file module for testing python imports

# Simple test function
def test_meta_function(query: dict) -> dict:
  return query

def main_question() -> str:
  return "Why?"
